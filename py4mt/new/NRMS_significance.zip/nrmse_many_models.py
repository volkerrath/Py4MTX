"""
Comparing NRMSE Across Many Models (>10)
==========================================
When you have K models, naive pairwise comparisons inflate false positives.
This script implements four strategies:

1. Pairwise Diebold-Mariano with multiplicity corrections
   (Bonferroni, Holm, Benjamini-Hochberg)
2. Model Confidence Set (Hansen, Lunde & Nason, 2011)
3. Bootstrap Reality Check vs. a benchmark (White, 2000)
4. Summary heatmap & ranking table

Usage:
    Replace the synthetic data block with your own arrays.
    observed : (n,) array
    predictions : dict  { "model_name": (n,) array of predictions }
"""

import numpy as np
from scipy import stats
from itertools import combinations


# ──────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────

def rmse(obs, pred):
    return np.sqrt(np.mean((obs - pred) ** 2))


def nrmse(obs, pred, norm="range"):
    r = rmse(obs, pred)
    if norm == "range":
        return r / np.ptp(obs)
    elif norm == "mean":
        return r / np.mean(obs)
    elif norm == "std":
        return r / np.std(obs, ddof=1)
    raise ValueError(f"Unknown norm: {norm}")


def dm_test(obs, p1, p2, loss="squared", h=1):
    """Diebold-Mariano test. Returns (statistic, two-sided p-value)."""
    e1, e2 = obs - p1, obs - p2
    if loss == "squared":
        d = e1**2 - e2**2
    else:
        d = np.abs(e1) - np.abs(e2)

    n = len(d)
    mean_d = np.mean(d)

    # HAC variance (Newey-West, h-1 lags)
    gamma_0 = np.mean((d - mean_d) ** 2)
    gamma_sum = sum(
        np.mean((d[k:] - mean_d) * (d[:-k] - mean_d)) for k in range(1, h)
    )
    var_d = (gamma_0 + 2 * gamma_sum) / n
    if var_d <= 0:
        var_d = gamma_0 / n

    dm = mean_d / np.sqrt(var_d)
    p = 2 * stats.norm.sf(np.abs(dm))
    return dm, p


# ──────────────────────────────────────────────────────────────
# 1. Pairwise DM tests + multiplicity corrections
# ──────────────────────────────────────────────────────────────

def pairwise_dm_tests(obs, predictions, loss="squared", h=1):
    """
    Run DM test for every pair of models.

    Returns
    -------
    results : list of dicts with keys
        model_a, model_b, dm_stat, p_raw
    raw_pvals : array of raw p-values (for correction)
    """
    names = list(predictions.keys())
    results = []
    for a, b in combinations(names, 2):
        dm_stat, p_raw = dm_test(obs, predictions[a], predictions[b], loss, h)
        results.append({
            "model_a": a, "model_b": b,
            "dm_stat": dm_stat, "p_raw": p_raw,
        })
    return results


def correct_pvalues(results):
    """
    Add Bonferroni, Holm, and Benjamini-Hochberg corrected p-values.
    Modifies results in-place and returns them.
    """
    m = len(results)
    raw = np.array([r["p_raw"] for r in results])

    # Bonferroni
    bonf = np.minimum(raw * m, 1.0)

    # Holm (step-down)
    order = np.argsort(raw)
    holm = np.empty(m)
    for rank_idx, orig_idx in enumerate(order):
        holm[orig_idx] = raw[orig_idx] * (m - rank_idx)
    # enforce monotonicity
    cummax = 0.0
    for orig_idx in order:
        cummax = max(cummax, holm[orig_idx])
        holm[orig_idx] = min(cummax, 1.0)

    # Benjamini-Hochberg (FDR)
    bh = np.empty(m)
    rev_order = order[::-1]
    cummin = 1.0
    for orig_idx in rev_order:
        rank = np.searchsorted(order, np.where(order == orig_idx)[0][0]) + 1
        # simpler: use sorted rank
        pass
    # Cleaner BH implementation
    sorted_idx = np.argsort(raw)
    bh_sorted = np.empty(m)
    for i, idx in enumerate(sorted_idx):
        rank = i + 1
        bh_sorted[i] = raw[idx] * m / rank
    # enforce monotonicity from the bottom
    cummin = 1.0
    for i in range(m - 1, -1, -1):
        cummin = min(cummin, bh_sorted[i])
        bh_sorted[i] = cummin
    bh = np.empty(m)
    for i, idx in enumerate(sorted_idx):
        bh[idx] = bh_sorted[i]

    for i, r in enumerate(results):
        r["p_bonferroni"] = bonf[i]
        r["p_holm"] = holm[i]
        r["p_bh"] = bh[i]

    return results


# ──────────────────────────────────────────────────────────────
# 2. Model Confidence Set (MCS) — simplified implementation
#    Hansen, Lunde & Nason (2011)
# ──────────────────────────────────────────────────────────────

def model_confidence_set(obs, predictions, alpha=0.10, B=5000, loss="squared", seed=42):
    """
    Iteratively eliminate the worst model until we can't reject
    that the survivors are equally good. The surviving set is the
    Model Confidence Set at level alpha.

    Uses the T_max statistic with block bootstrap (block=1 here,
    i.e. iid bootstrap — increase block_len for time series).

    Returns
    -------
    mcs_models : list of model names in the confidence set
    eliminated : list of (model_name, p_value) in elimination order
    """
    rng = np.random.default_rng(seed)
    names = list(predictions.keys())
    preds = {k: predictions[k] for k in names}
    n = len(obs)

    # Loss matrix: L[i, t] = loss of model i at time t
    def loss_matrix(model_names):
        if loss == "squared":
            return np.array([(obs - preds[m]) ** 2 for m in model_names])
        else:
            return np.array([np.abs(obs - preds[m]) for m in model_names])

    eliminated = []
    active = list(names)

    while len(active) > 1:
        L = loss_matrix(active)
        k = len(active)

        # d_i(t) = L_i(t) - (1/k) sum_j L_j(t)
        mean_losses = L.mean(axis=1)                # (k,)
        d_bar = mean_losses - mean_losses.mean()    # (k,) deviations

        # Estimate variance of d_i_bar via bootstrap
        boot_d = np.empty((B, k))
        for b in range(B):
            idx = rng.integers(0, n, size=n)
            L_b = L[:, idx]
            ml_b = L_b.mean(axis=1)
            boot_d[b] = ml_b - ml_b.mean()

        # Variance from bootstrap (per model)
        var_d = np.var(boot_d, axis=0, ddof=1)
        var_d = np.maximum(var_d, 1e-15)  # avoid division by zero

        # T_max statistic: max over models of |t_i|
        t_obs = d_bar / np.sqrt(var_d)
        t_max_obs = np.max(np.abs(t_obs))

        # Bootstrap distribution of T_max under H0 (centre at 0)
        boot_centered = boot_d - boot_d.mean(axis=0)
        boot_t = boot_centered / np.sqrt(var_d)
        boot_tmax = np.max(np.abs(boot_t), axis=1)

        # p-value for the null "all active models are equally good"
        p_equiv = np.mean(boot_tmax >= t_max_obs)

        if p_equiv >= alpha:
            break

        # Eliminate the model with the worst (highest) average loss
        worst_idx = np.argmax(mean_losses)
        worst_model = active[worst_idx]
        eliminated.append((worst_model, p_equiv))
        active.pop(worst_idx)

    return active, eliminated


# ──────────────────────────────────────────────────────────────
# 3. Bootstrap Reality Check (White, 2000)
#    Test H0: no model beats the benchmark
# ──────────────────────────────────────────────────────────────

def reality_check(obs, benchmark_pred, challenger_preds, B=5000, seed=42):
    """
    White's Reality Check: tests whether ANY challenger model
    significantly outperforms the benchmark.

    Returns
    -------
    dict with:
        rc_stat     : max mean loss improvement over benchmark
        p_value     : bootstrap p-value for H0 (no model beats benchmark)
        individual  : dict of model-name → mean loss improvement
    """
    rng = np.random.default_rng(seed)
    n = len(obs)
    e_bench = (obs - benchmark_pred) ** 2  # benchmark squared errors

    # f_k(t) = L_bench(t) - L_k(t)  (positive = challenger k is better)
    challengers = {}
    for name, pred in challenger_preds.items():
        challengers[name] = e_bench - (obs - pred) ** 2

    f_matrix = np.array(list(challengers.values()))  # (K, n)
    f_means = f_matrix.mean(axis=1)                   # (K,)
    rc_stat = np.max(f_means)                          # observed test stat

    # Bootstrap under H0 (centre at zero)
    f_centered = f_matrix - f_means[:, None]
    boot_stats = np.empty(B)
    for b in range(B):
        idx = rng.integers(0, n, size=n)
        boot_means = f_centered[:, idx].mean(axis=1)
        boot_stats[b] = np.max(boot_means)

    p_value = np.mean(boot_stats >= rc_stat)

    individual = {name: f_means[i] for i, name in enumerate(challengers)}
    return {"rc_stat": rc_stat, "p_value": p_value, "individual": individual}


# ──────────────────────────────────────────────────────────────
# 4. Pretty printing
# ──────────────────────────────────────────────────────────────

def print_ranking(obs, predictions, norm="range"):
    """Print models ranked by NRMSE."""
    scores = {m: nrmse(obs, p, norm) for m, p in predictions.items()}
    ranked = sorted(scores.items(), key=lambda x: x[1])
    print("=" * 50)
    print(f"  {'Rank':<6}{'Model':<20}{'NRMSE':>10}")
    print("-" * 50)
    for i, (name, score) in enumerate(ranked, 1):
        print(f"  {i:<6}{name:<20}{score:>10.4f}")
    print("=" * 50)
    return ranked


def print_pairwise(results, method="p_bh", alpha=0.05, top_n=20):
    """Print most significant pairwise comparisons."""
    srt = sorted(results, key=lambda r: r["p_raw"])[:top_n]
    print(f"\n  {'Model A':<12}{'Model B':<12}{'DM stat':>9}{'p_raw':>9}"
          f"{'p_' + method.split('_')[1]:>9}  {'Sig?':>5}")
    print("  " + "-" * 58)
    for r in srt:
        sig = "*" if r[method] < alpha else ""
        print(f"  {r['model_a']:<12}{r['model_b']:<12}"
              f"{r['dm_stat']:>9.3f}{r['p_raw']:>9.4f}"
              f"{r[method]:>9.4f}  {sig:>5}")


# ──────────────────────────────────────────────────────────────
# 5. Demo
# ──────────────────────────────────────────────────────────────

if __name__ == "__main__":

    np.random.seed(42)
    n = 300

    # ---- Synthetic data ----
    x = np.linspace(0, 6 * np.pi, n)
    observed = np.sin(x) + 0.3 * np.random.randn(n)

    # Generate 12 models with varying quality
    predictions = {}
    for i in range(12):
        noise_level = 0.05 + i * 0.03          # worse as i grows
        phase_shift = i * 0.02                  # small bias
        pred = np.sin(x + phase_shift) + noise_level * np.random.randn(n)
        predictions[f"model_{i+1:02d}"] = pred

    # ──────────────────────────────────────────
    # A) Ranking
    # ──────────────────────────────────────────
    print("\n>>> MODEL RANKING BY NRMSE\n")
    ranked = print_ranking(observed, predictions)

    # ──────────────────────────────────────────
    # B) Pairwise DM + corrections
    # ──────────────────────────────────────────
    print("\n>>> PAIRWISE DIEBOLD-MARIANO TESTS (top 20)")
    print("    (Benjamini-Hochberg correction for FDR)\n")
    results = pairwise_dm_tests(observed, predictions)
    results = correct_pvalues(results)
    print_pairwise(results, method="p_bh", alpha=0.05)

    k = len(predictions)
    n_pairs = k * (k - 1) // 2
    n_sig_raw = sum(1 for r in results if r["p_raw"] < 0.05)
    n_sig_bh  = sum(1 for r in results if r["p_bh"] < 0.05)
    n_sig_bonf = sum(1 for r in results if r["p_bonferroni"] < 0.05)
    print(f"\n  Total pairs: {n_pairs}")
    print(f"  Significant (raw p<.05):        {n_sig_raw}")
    print(f"  Significant (BH FDR<.05):       {n_sig_bh}")
    print(f"  Significant (Bonferroni<.05):    {n_sig_bonf}")

    # ──────────────────────────────────────────
    # C) Model Confidence Set
    # ──────────────────────────────────────────
    print("\n\n>>> MODEL CONFIDENCE SET (alpha=0.10)\n")
    mcs, elim = model_confidence_set(observed, predictions, alpha=0.10, B=5000)
    print(f"  MCS contains {len(mcs)} model(s):")
    for m in mcs:
        print(f"    - {m}  (NRMSE = {nrmse(observed, predictions[m]):.4f})")
    if elim:
        print(f"\n  Elimination order:")
        for m, p in elim:
            print(f"    Removed {m:<14} (p = {p:.4f})")

    # ──────────────────────────────────────────
    # D) Reality Check vs. benchmark (model_01)
    # ──────────────────────────────────────────
    print("\n\n>>> WHITE'S REALITY CHECK (benchmark = model_01)\n")
    benchmark = "model_01"
    challengers = {k: v for k, v in predictions.items() if k != benchmark}
    rc = reality_check(observed, predictions[benchmark], challengers, B=5000)
    print(f"  RC statistic:  {rc['rc_stat']:.6f}")
    print(f"  p-value:       {rc['p_value']:.4f}")
    if rc["p_value"] < 0.05:
        print("  → At least one challenger significantly beats the benchmark.")
    else:
        print("  → No challenger significantly beats the benchmark.")
    print(f"\n  Individual mean loss improvements over {benchmark}:")
    for m, v in sorted(rc["individual"].items(), key=lambda x: -x[1]):
        direction = "better" if v > 0 else "worse"
        print(f"    {m}: {v:+.6f} ({direction})")
