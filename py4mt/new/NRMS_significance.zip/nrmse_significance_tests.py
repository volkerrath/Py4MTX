"""
Statistical Tests for Comparing NRMSE Between Two Models
=========================================================
1. Bootstrap test for NRMSE difference
2. Diebold-Mariano test for equal predictive accuracy

Usage:
    - Replace `observed`, `pred_model1`, `pred_model2` with your own data.
    - Run the script to get p-values and confidence intervals.
"""

import numpy as np
from scipy import stats


# ──────────────────────────────────────────────────────────────
# 1. NRMSE helpers
# ──────────────────────────────────────────────────────────────

def rmse(observed, predicted):
    return np.sqrt(np.mean((observed - predicted) ** 2))


def nrmse(observed, predicted, normalization="range"):
    """
    Normalized RMSE.

    normalization : str
        'range'  → divide by (max - min) of observed
        'mean'   → divide by mean of observed
        'std'    → divide by std of observed
        'iqr'    → divide by interquartile range of observed
    """
    r = rmse(observed, predicted)
    if normalization == "range":
        denom = np.ptp(observed)  # max - min
    elif normalization == "mean":
        denom = np.mean(observed)
    elif normalization == "std":
        denom = np.std(observed, ddof=1)
    elif normalization == "iqr":
        denom = np.subtract(*np.percentile(observed, [75, 25]))
    else:
        raise ValueError(f"Unknown normalization: {normalization}")
    return r / denom


# ──────────────────────────────────────────────────────────────
# 2. Bootstrap test for NRMSE difference
# ──────────────────────────────────────────────────────────────

def bootstrap_nrmse_test(
    observed, pred1, pred2,
    n_bootstrap=10_000,
    confidence=0.95,
    normalization="range",
    seed=42,
):
    """
    Bootstrap test: is NRMSE(model1) significantly different from NRMSE(model2)?

    Returns
    -------
    dict with:
        nrmse1, nrmse2          : point estimates
        delta                   : nrmse1 - nrmse2  (negative → model1 is better)
        ci_lower, ci_upper      : confidence interval for delta
        p_value                 : two-sided p-value (H0: delta == 0)
        bootstrap_deltas        : array of bootstrapped deltas
    """
    rng = np.random.default_rng(seed)
    n = len(observed)

    nrmse1 = nrmse(observed, pred1, normalization)
    nrmse2 = nrmse(observed, pred2, normalization)
    delta_obs = nrmse1 - nrmse2

    deltas = np.empty(n_bootstrap)
    for i in range(n_bootstrap):
        idx = rng.integers(0, n, size=n)
        obs_b = observed[idx]
        p1_b = pred1[idx]
        p2_b = pred2[idx]
        deltas[i] = nrmse(obs_b, p1_b, normalization) - nrmse(obs_b, p2_b, normalization)

    alpha = 1 - confidence
    ci_lower = np.percentile(deltas, 100 * alpha / 2)
    ci_upper = np.percentile(deltas, 100 * (1 - alpha / 2))

    # Two-sided p-value via the percentile method:
    # proportion of bootstrap deltas on the opposite side of zero
    # (or more extreme) from the observed delta.
    # Shift bootstrap distribution to be centred at 0 (H0), then
    # check how often the shifted deltas are as extreme as observed.
    shifted = deltas - np.mean(deltas)          # centre at 0
    p_value = np.mean(np.abs(shifted) >= np.abs(delta_obs))

    return {
        "nrmse1": nrmse1,
        "nrmse2": nrmse2,
        "delta": delta_obs,
        "ci_lower": ci_lower,
        "ci_upper": ci_upper,
        "p_value": p_value,
        "bootstrap_deltas": deltas,
    }


# ──────────────────────────────────────────────────────────────
# 3. Diebold-Mariano test
# ──────────────────────────────────────────────────────────────

def diebold_mariano_test(
    observed, pred1, pred2,
    loss="squared",
    h=1,
    alternative="two-sided",
):
    """
    Diebold-Mariano (1995) test for equal predictive accuracy.

    H0 : E[d_t] = 0   where d_t = L(e1_t) - L(e2_t)
    H1 : E[d_t] != 0  (or one-sided)

    Parameters
    ----------
    observed : array-like
    pred1, pred2 : array-like, predictions from model 1 and model 2
    loss : str
        'squared'  → L(e) = e^2      (tests MSE difference)
        'absolute' → L(e) = |e|       (tests MAE difference)
    h : int
        Forecast horizon (used for HAC variance with h-1 lags).
        Use h=1 for 1-step-ahead or non-time-series data.
    alternative : str
        'two-sided', 'less' (model1 better), 'greater' (model2 better)

    Returns
    -------
    dict with:
        dm_stat   : Diebold-Mariano test statistic
        p_value   : p-value under chosen alternative
        mean_d    : mean loss differential
        se_d      : HAC standard error of mean loss differential
    """
    e1 = observed - pred1
    e2 = observed - pred2

    if loss == "squared":
        d = e1 ** 2 - e2 ** 2
    elif loss == "absolute":
        d = np.abs(e1) - np.abs(e2)
    else:
        raise ValueError(f"Unknown loss: {loss}")

    n = len(d)
    mean_d = np.mean(d)

    # Newey-West / HAC variance estimator with (h-1) lags
    gamma_0 = np.mean((d - mean_d) ** 2)
    gamma_sum = 0.0
    for k in range(1, h):
        gamma_k = np.mean((d[k:] - mean_d) * (d[:-k] - mean_d))
        gamma_sum += gamma_k

    var_d = (gamma_0 + 2 * gamma_sum) / n

    if var_d <= 0:
        # Fallback: use simple variance if HAC estimate is non-positive
        var_d = gamma_0 / n

    se_d = np.sqrt(var_d)
    dm_stat = mean_d / se_d

    # p-value
    if alternative == "two-sided":
        p_value = 2 * stats.norm.sf(np.abs(dm_stat))
    elif alternative == "less":
        # H1: model1 is better (mean_d < 0)
        p_value = stats.norm.cdf(dm_stat)
    elif alternative == "greater":
        # H1: model2 is better (mean_d > 0)
        p_value = stats.norm.sf(dm_stat)
    else:
        raise ValueError(f"Unknown alternative: {alternative}")

    return {
        "dm_stat": dm_stat,
        "p_value": p_value,
        "mean_d": mean_d,
        "se_d": se_d,
    }


# ──────────────────────────────────────────────────────────────
# 4. Demo with synthetic data
# ──────────────────────────────────────────────────────────────

if __name__ == "__main__":

    np.random.seed(0)
    n = 200

    # Synthetic observed signal
    x = np.linspace(0, 4 * np.pi, n)
    observed = np.sin(x) + 0.3 * np.random.randn(n)

    # Model 1: decent fit
    pred_model1 = np.sin(x) + 0.1 * np.random.randn(n)

    # Model 2: slightly worse fit
    pred_model2 = np.sin(x + 0.2) + 0.15 * np.random.randn(n)

    # --- Point estimates ---
    n1 = nrmse(observed, pred_model1)
    n2 = nrmse(observed, pred_model2)
    print("=" * 60)
    print("NRMSE Comparison")
    print("=" * 60)
    print(f"  Model 1 NRMSE (range): {n1:.4f}")
    print(f"  Model 2 NRMSE (range): {n2:.4f}")
    print(f"  Difference (M1 - M2):  {n1 - n2:.4f}")
    print()

    # --- Bootstrap test ---
    boot = bootstrap_nrmse_test(observed, pred_model1, pred_model2)
    print("-" * 60)
    print("Bootstrap Test for NRMSE Difference")
    print("-" * 60)
    print(f"  Delta (M1 - M2):       {boot['delta']:.4f}")
    print(f"  95% CI:                [{boot['ci_lower']:.4f}, {boot['ci_upper']:.4f}]")
    print(f"  p-value:               {boot['p_value']:.4f}")
    sig = "YES" if boot["p_value"] < 0.05 else "NO"
    print(f"  Significant at 0.05?   {sig}")
    print()

    # --- Diebold-Mariano test ---
    dm = diebold_mariano_test(observed, pred_model1, pred_model2)
    print("-" * 60)
    print("Diebold-Mariano Test (squared loss)")
    print("-" * 60)
    print(f"  DM statistic:          {dm['dm_stat']:.4f}")
    print(f"  p-value (two-sided):   {dm['p_value']:.4f}")
    sig = "YES" if dm["p_value"] < 0.05 else "NO"
    print(f"  Significant at 0.05?   {sig}")
    print()

    # --- One-sided: is model 1 significantly BETTER? ---
    dm_less = diebold_mariano_test(
        observed, pred_model1, pred_model2, alternative="less"
    )
    print(f"  One-sided (M1 better): p = {dm_less['p_value']:.4f}")
