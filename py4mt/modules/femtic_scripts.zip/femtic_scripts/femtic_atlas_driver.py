#!/usr/bin/env python3
"""
femtic_atlas_driver.py

Driver script to generate a small "atlas" of FEMTIC model plots from a single
NPZ file created by femtic_mesh_to_npz.py:

- Horizontal map slices at a set of depths (z0, dz) using Matplotlib.
- Vertical curtain slices along arbitrary polylines (CSV) using Matplotlib.

Interpolation methods
---------------------
All slices use a common interpolation method, passed via:

    --interp idw|nearest|rbf

Author: Volker Rath (DIAS)
Created by ChatGPT (GPT-5 Thinking) on 2025-12-08
"""
from __future__ import annotations

from pathlib import Path
from typing import Sequence

from femtic_slice_matplotlib import femtic_slice_from_npz_matplotlib
from femtic_map_slice_matplotlib import femtic_map_slice_from_npz_matplotlib


def _ensure_dir(path: str | Path) -> Path:
    """Ensure that a directory exists, create it if necessary."""
    dir_path = Path(path).expanduser().resolve()
    dir_path.mkdir(parents=True, exist_ok=True)
    return dir_path


def _stem(path: str | Path) -> str:
    """Return the stem (filename without extension) of a path."""
    return Path(path).stem


def run_maps(
    npz_path: str | Path,
    out_dir: str | Path,
    depths: Sequence[float],
    dz: float,
    *,
    nx: int = 200,
    ny: int = 200,
    xmin: float | None = None,
    xmax: float | None = None,
    ymin: float | None = None,
    ymax: float | None = None,
    power: float = 2.0,
    interp: str = "idw",
    logscale: bool = True,
    cmap: str = "viridis",
    vmin: float | None = None,
    vmax: float | None = None,
) -> None:
    """Generate horizontal map slices at a set of depths."""
    out_dir = _ensure_dir(out_dir)
    npz_path = str(npz_path)
    prefix = _stem(npz_path)
    for z0 in depths:
        tag = f"z{z0:+g}".replace("+", "").replace(".", "p").replace("-", "m")
        base = f"{prefix}_map_{tag}"
        out_npz = str(out_dir / f"{base}.npz")
        out_csv = str(out_dir / f"{base}.csv")
        out_png = str(out_dir / f"{base}.png")
        print(f"[MAP] depth {z0:g}, dz={dz:g}, interp={interp} -> {out_png}")
        femtic_map_slice_from_npz_matplotlib(
            npz_path=npz_path,
            z0=z0,
            dz=dz,
            nx=nx,
            ny=ny,
            xmin=xmin,
            xmax=xmax,
            ymin=ymin,
            ymax=ymax,
            power=power,
            interp=interp,
            logscale=logscale,
            cmap=cmap,
            vmin=vmin,
            vmax=vmax,
            out_npz=out_npz,
            out_csv=out_csv,
            out_png=out_png,
            title="Horizontal slice",
        )


def run_curtains(
    npz_path: str | Path,
    out_dir: str | Path,
    curtain_csvs: Sequence[str | Path],
    *,
    zmin: float,
    zmax: float,
    nz: int = 201,
    ns: int = 301,
    power: float = 2.0,
    interp: str = "idw",
    logscale: bool = True,
    z_positive_down: bool = True,
    cmap: str = "viridis",
    vmin: float | None = None,
    vmax: float | None = None,
) -> None:
    """Generate vertical curtain slices for one or more polylines."""
    out_dir = _ensure_dir(out_dir)
    npz_path = str(npz_path)
    prefix = _stem(npz_path)
    for csv_path in curtain_csvs:
        csv_path = str(csv_path)
        name = _stem(csv_path)
        base = f"{prefix}_curtain_{name}"
        out_npz = str(out_dir / f"{base}.npz")
        out_csv = str(out_dir / f"{base}.csv")
        out_png = str(out_dir / f"{base}.png")
        print(f"[CURTAIN] {csv_path}, interp={interp} -> {out_png}")
        femtic_slice_from_npz_matplotlib(
            npz_path=npz_path,
            polyline_xy=None,
            polyline_csv=csv_path,
            zmin=zmin,
            zmax=zmax,
            nz=nz,
            ns=ns,
            power=power,
            interp=interp,
            logscale=logscale,
            z_positive_down=z_positive_down,
            cmap=cmap,
            vmin=vmin,
            vmax=vmax,
            out_npz=out_npz,
            out_csv=out_csv,
            out_png=out_png,
            title=f"Curtain: {name}",
        )


def main() -> None:
    """CLI driver for generating FEMTIC maps and curtains from NPZ."""
    import argparse

    ap = argparse.ArgumentParser(
        description=(
            "Generate horizontal maps and vertical curtain slices from a "
            "FEMTIC NPZ model using Matplotlib."
        )
    )
    ap.add_argument("--npz", required=True, help="FEMTIC NPZ from femtic_mesh_to_npz.py.")
    ap.add_argument(
        "--out-dir",
        default="atlas",
        help="Output directory for all generated plots and NPZ/CSV files.",
    )

    # Map options
    ap.add_argument(
        "--map-depth",
        action="append",
        type=float,
        default=[],
        help="Central depth z0 for a horizontal slice; may be given multiple times.",
    )
    ap.add_argument(
        "--map-dz",
        type=float,
        default=200.0,
        help="Vertical window thickness for horizontal slices.",
    )
    ap.add_argument("--map-nx", type=int, default=200, help="Grid points in x for maps.")
    ap.add_argument("--map-ny", type=int, default=200, help="Grid points in y for maps.")
    ap.add_argument("--map-xmin", type=float, default=None, help="Min x for maps.")
    ap.add_argument("--map-xmax", type=float, default=None, help="Max x for maps.")
    ap.add_argument("--map-ymin", type=float, default=None, help="Min y for maps.")
    ap.add_argument("--map-ymax", type=float, default=None, help="Max y for maps.")

    # Curtain options
    ap.add_argument(
        "--curtain-csv",
        action="append",
        default=[],
        help="CSV with polyline vertices (x,y) for a curtain; may be repeated.",
    )
    ap.add_argument(
        "--curtain-zmin",
        type=float,
        default=None,
        help="Minimum depth for curtains (required if any --curtain-csv is given).",
    )
    ap.add_argument(
        "--curtain-zmax",
        type=float,
        default=None,
        help="Maximum depth for curtains (required if any --curtain-csv is given).",
    )
    ap.add_argument("--curtain-nz", type=int, default=201, help="Depth samples for curtains.")
    ap.add_argument("--curtain-ns", type=int, default=301, help="Samples along polyline for curtains.")

    # Shared interpolation / plotting options
    ap.add_argument("--power", type=float, default=2.0, help="IDW power exponent (interp='idw').")
    ap.add_argument(
        "--interp",
        choices=["idw", "nearest", "rbf"],
        default="idw",
        help="Interpolation method used for all slices.",
    )
    ap.add_argument("--logscale", action="store_true", help="Plot log10(ρ) instead of linear ρ.")
    ap.add_argument(
        "--z-positive-down",
        action="store_true",
        help="Curtain plots: depth increases downwards if set.",
    )
    ap.add_argument("--cmap", default="viridis", help="Matplotlib colormap.")
    ap.add_argument("--vmin", type=float, default=None, help="Colour scale minimum.")
    ap.add_argument("--vmax", type=float, default=None, help="Colour scale maximum.")

    args = ap.parse_args()

    npz_path = args.npz
    out_dir = args.out_dir

    do_maps = len(args.map_depth) > 0
    do_curtains = len(args.curtain_csv) > 0

    if not (do_maps or do_curtains):
        raise SystemExit(
            "Nothing to do: specify at least one --map-depth or one --curtain-csv."
        )

    if do_maps:
        run_maps(
            npz_path=npz_path,
            out_dir=out_dir,
            depths=args.map_depth,
            dz=args.map_dz,
            nx=args.map_nx,
            ny=args.map_ny,
            xmin=args.map_xmin,
            xmax=args.map_xmax,
            ymin=args.map_ymin,
            ymax=args.map_ymax,
            power=args.power,
            interp=args.interp,
            logscale=args.logscale,
            cmap=args.cmap,
            vmin=args.vmin,
            vmax=args.vmax,
        )

    if do_curtains:
        if args.curtain_zmin is None or args.curtain_zmax is None:
            raise SystemExit(
                "For curtains, both --curtain-zmin and --curtain-zmax must be provided."
            )
        run_curtains(
            npz_path=npz_path,
            out_dir=out_dir,
            curtain_csvs=args.curtain_csv,
            zmin=args.curtain_zmin,
            zmax=args.curtain_zmax,
            nz=args.curtain_nz,
            ns=args.curtain_ns,
            power=args.power,
            interp=args.interp,
            logscale=args.logscale,
            z_positive_down=args.z_positive_down,
            cmap=args.cmap,
            vmin=args.vmin,
            vmax=args.vmax,
        )


if __name__ == "__main__":
    main()
