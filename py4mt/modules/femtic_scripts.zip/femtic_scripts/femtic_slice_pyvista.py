#!/usr/bin/env python3
"""
femtic_slice_pyvista.py

Vertical FEMTIC resistivity slices (curtains) from NPZ using PyVista.

This script reuses the interpolation logic from femtic_slice_matplotlib
(curtain_slice) and builds a 2-D PyVista StructuredGrid in (S, z)-space, where:

    S : distance along polyline
    z : depth (positive downwards if requested)

Cell data:
    log10_rho  (log10_resistivity in NPZ)
    rho        (10**log10_rho)

Author: Volker Rath (DIAS)
Created by ChatGPT (GPT-5 Thinking) on 2025-12-08
"""
from __future__ import annotations

import numpy as np


def build_curtain_grid_from_npz(
    npz_path: str,
    *,
    polyline_xy: np.ndarray | None = None,
    polyline_csv: str | None = None,
    zmin: float,
    zmax: float,
    nz: int = 201,
    ns: int = 301,
    interp: str = "idw",
    power: float = 2.0,
) -> "pyvista.StructuredGrid":
    """Build a PyVista StructuredGrid for a vertical curtain.

    Parameters
    ----------
    npz_path : str
        FEMTIC NPZ created by femtic_mesh_to_npz.py.
    polyline_xy : ndarray, shape (m, 2), optional
        Polyline vertices in XY. Ignored if polyline_csv is given.
    polyline_csv : str, optional
        CSV file with at least 'x,y' in the first two columns.
    zmin, zmax : float
        Depth range of curtain.
    nz : int
        Number of samples in depth.
    ns : int
        Number of samples along polyline.
    interp : {'idw', 'nearest', 'rbf'}
        Interpolation method (same as femtic_slice_matplotlib).
    power : float
        IDW exponent if interp='idw'.

    Returns
    -------
    grid : pyvista.StructuredGrid
        Structured grid in (S, z) coordinates with 'log10_rho' and 'rho'.
    """
    try:
        import pyvista as pv
    except Exception as exc:  # pragma: no cover
        raise ImportError("pyvista is required for curtain plotting.") from exc

    from femtic_slice_matplotlib import curtain_slice  # reuse interpolation

    import csv

    data = np.load(npz_path)
    if "centroid" not in data or "log10_resistivity" not in data:
        raise KeyError("NPZ must contain 'centroid' and 'log10_resistivity'.")

    centroids = data["centroid"]
    vals_log10 = data["log10_resistivity"]
    if "flag" in data:
        mask = data["flag"] != 1
        centroids = centroids[mask]
        vals_log10 = vals_log10[mask]

    if polyline_csv is not None:
        pts = []
        with open(polyline_csv, "r") as f:
            r = csv.reader(f)
            for row in r:
                if not row:
                    continue
                try:
                    x = float(row[0])
                    y = float(row[1])
                except Exception:
                    continue
                pts.append([x, y])
        if len(pts) < 2:
            raise ValueError("Polyline CSV must contain at least two vertices.")
        poly_xy = np.asarray(pts, dtype=float)
    else:
        if polyline_xy is None or polyline_xy.shape[0] < 2:
            raise ValueError("Provide at least two polyline vertices via polyline_xy.")
        poly_xy = np.asarray(polyline_xy, dtype=float)

    Z = np.linspace(zmin, zmax, nz)
    S, Z, V_log10, XY = curtain_slice(
        poly_xy,
        Z,
        centroids,
        vals_log10,
        interp=interp,
        power=power,
        ns=ns,
    )

    # Build StructuredGrid in (S, z) plane, y=0
    S2, Z2 = np.meshgrid(S, Z)  # (nz, ns)
    X = S2
    Y = np.zeros_like(S2)
    Zcoords = Z2

    # Shape to (nz, ns, 1) for StructuredGrid
    X3 = X[:, :, None]
    Y3 = Y[:, :, None]
    Z3 = Zcoords[:, :, None]

    grid = pv.StructuredGrid(X3, Y3, Z3)
    grid["log10_rho"] = V_log10.ravel(order="C")
    grid["rho"] = (10.0 ** V_log10).ravel(order="C")

    # Optionally store polyline locations as field data
    grid.field_data["polyline_xy"] = XY

    return grid


def main() -> None:
    """CLI entry point for PyVista curtain slices."""
    import argparse
    import pyvista as pv

    ap = argparse.ArgumentParser(
        description="Vertical FEMTIC curtain slices in (S, z) using PyVista."
    )
    ap.add_argument("--npz", required=True, help="Element NPZ from femtic_mesh_to_npz.py.")
    ap.add_argument("--polyline-csv", help="CSV file with x,y columns for polyline vertices.")
    ap.add_argument(
        "--xy",
        action="append",
        nargs=2,
        type=float,
        metavar=("X", "Y"),
        help="Polyline vertex (X Y). Repeat to build polyline.",
    )
    ap.add_argument("--zmin", type=float, required=True, help="Minimum depth of slice.")
    ap.add_argument("--zmax", type=float, required=True, help="Maximum depth of slice.")
    ap.add_argument("--nz", type=int, default=201, help="Number of depth samples.")
    ap.add_argument("--ns", type=int, default=301, help="Number of samples along slice.")
    ap.add_argument(
        "--interp",
        choices=["idw", "nearest", "rbf"],
        default="idw",
        help="Interpolation method.",
    )
    ap.add_argument("--power", type=float, default=2.0, help="IDW power exponent.")
    ap.add_argument("--out-vtk", default=None, help="Optional output .vts/.vtk file.")
    ap.add_argument(
        "--no-show",
        action="store_true",
        help="Do not open interactive PyVista window.",
    )
    args = ap.parse_args()

    polyline_xy = None
    if args.polyline_csv is None:
        if not args.xy or len(args.xy) < 2:
            raise ValueError(
                "Provide a polyline via --polyline-csv or at least two --xy X Y pairs."
            )
        polyline_xy = np.asarray([[x, y] for x, y in args.xy], dtype=float)

    grid = build_curtain_grid_from_npz(
        args.npz,
        polyline_xy=polyline_xy,
        polyline_csv=args.polyline_csv,
        zmin=args.zmin,
        zmax=args.zmax,
        nz=args.nz,
        ns=args.ns,
        interp=args.interp,
        power=args.power,
    )

    if args.out_vtk is not None:
        grid.save(args.out_vtk)
        print("Saved curtain grid to:", args.out_vtk)

    if not args.no_show:
        grid.plot(
            scalars="log10_rho",
            cmap="viridis",
        )


if __name__ == "__main__":  # pragma: no cover
    main()
