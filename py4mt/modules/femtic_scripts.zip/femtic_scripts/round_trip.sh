#!/usr/bin/env bash

./femtic_mesh_to_npz.py \
  --mesh mesh.dat \
  --rho-block resistivity_block_iter2.dat \
  --out-npz femtic_model.npz

./femtic_npz_to_mesh.py \
  --npz femtic_model.npz \
  --mesh-out mesh_new.dat \
  --rho-block-out resistivity_block_iter2_new.dat
