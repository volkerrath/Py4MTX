#!/usr/bin/env python3

python femtic_mesh_to_npz.py \
  --mesh mesh.dat \
  --rho-block resistivity_block_iter0.dat \
  --out-npz femtic_model.npz


python femtic_npz_to_femtic.py \
  --npz femtic_model.npz \
  --mesh-out mesh_new.dat \
  --rho-block-out resistivity_block_iter0_new.dat
