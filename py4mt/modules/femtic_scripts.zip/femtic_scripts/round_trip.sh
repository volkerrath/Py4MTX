#!/usr/bin/env bash

# ./femtic_mesh_to_npz.py \
#   --mesh mesh.dat \
#   --rho-block resistivity_block_iter2.dat \
#   --out-npz femtic_model.npz
#
# ./femtic_npz_to_mesh.py \
#   --npz femtic_model.npz \
#   --mesh-out mesh_new.dat \
#   --rho-block-out resistivity_block_iter2_new.dat

./femtic_npz_to_vtk.py \
    --npz femtic_model.npz \
    --out-vtu femtic_model.vtu \
    --plot

./femtic_map_slice_matplotlib.py \
  --npz femtic_model.npz \
  --z0 10000 --dz 300 \
  --interp rbf \
  --logscale \
  --out-png map_rbf_z-1500.png

./femtic_slice_matplotlib.py \
  --npz femtic_model.npz \
  --polyline-csv transect_x.csv \
  --zmin -5500 --zmax 10000 \
  --interp nearest \
  --logscale --z-positive-down \
  --out-png curtain_nearest.png


./femtic_slice_matplotlib.py \
  --npz femtic_model.npz \
  --polyline-csv transect_x.csv \
  --zmin -5500 --zmax 10000 \
  --interp rbf \
  --logscale --z-positive-down \
  --out-png curtain_rbf.png


./femtic_map_slice_pyvista.py \
    --npz femtic_model.npz \
    --z0 -1500 --dz 300 \
    --interp nearest \
    --out-vtk map_z-1500.vts

./femtic_slice_pyvista.py \
    --npz femtic_model.npz \
    --polyline-csv transect_x.csv \
    --zmin -2500 --zmax 0 \
    --interp rbf \
    --out-vtk curtain_transect_x.vts
