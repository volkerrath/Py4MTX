#!/usr/bin/env bash

./femtic_mesh_to_npz.py \
  --mesh mesh.dat \
  --rho-block resistivity_block_iter2.dat \
  --out-npz femtic_model.npz

./femtic_slice_matplotlib.py \
  --npz femtic_model.npz \
  --polyline-csv polyline.csv \
  --zmin -2500 --zmax 0 --nz 201 --ns 301 \
  --logscale --z-positive-down \
  --out-png curtain.png

./femtic_map_slice_matplotlib \\
  --npz femtic_model.npz \\
  --z0 -1000 --dz 200 \\
  --nx 200 --ny 200 \\
  --logscale \\
  --out-png slice_z-1000.png


./femtic_npz_to_mesh.py \
  --npz femtic_model.npz \
  --mesh-out mesh_new.dat \
  --rho-block-out resistivity_block_iter2_new.dat
