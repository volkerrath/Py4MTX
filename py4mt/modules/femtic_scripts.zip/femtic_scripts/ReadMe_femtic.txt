FEMTIC Clean Rho Project
========================

Author: Volker Rath (DIAS)
Created by ChatGPT (GPT-5 Thinking) on 2025-12-07

Overview
--------

This mini-package provides a lightweight workflow around FEMTIC MT models:

- femtic_mesh_to_npz.py
    Read FEMTIC mesh.dat and resistivity_block_iterX.dat, build element-based
    arrays (centroid, region, log10_rho, lower/upper bounds, flag, n) and
    save them to a compressed NPZ file.

- femtic_rho_inject.py
    Inject region-based resistivity values (and optional bounds and n) into a
    FEMTIC rho / resistivity-block file. Only lines matching

        ireg  rho  rho_min  rho_max  n  flag

    are modified.

- femtic_profiles.py
    Compute vertical resistivity profiles at (x, y) locations using inverse-
    distance weighting (IDW) on element centroids, and plot them using pure
    Matplotlib via femtic_borehole_viz.

- femtic_polyline_slice.py
    Build a vertical "curtain" slice of resistivity along an XY polyline using
    IDW and element centroids. Optional visualisation with PyVista and export
    to NPZ/CSV/VTK/PNG.

- femtic_borehole_viz.py
    Small Matplotlib helper functions to plot one or multiple vertical
    borehole profiles.

- femtic_pipeline.py
    Simple wiring from a region-level NPZ (region_rho, optional bounds) to
    a rho / resistivity-block file using femtic_rho_inject.

Meaning of n (sharpness) and flag
---------------------------------

In resistivity_block_iterX.dat each region line has the form:

    ireg  rho  rho_min  rho_max  n  flag

where

- rho      : region resistivity [Ohm m]
- rho_min  : lower bound [Ohm m]
- rho_max  : upper bound [Ohm m]
- n        : sharpness parameter (usually 1, 2, or 3)
- flag     : 0 = free, 1 = fixed

flag (fixed / free)
-------------------

The flag controls whether the inversion updates a region:

- flag = 0  -> free  (region resistivity can change)
- flag = 1  -> fixed (region resistivity is held constant)

In the Python tools, if the element NPZ contains a "flag" array, elements with
flag == 1 are ignored in interpolation (profiles and curtains), so only free
elements contribute.

sharpness n
-----------

The sharpness parameter n controls how sharp or smooth transitions between
regions are allowed to be in the inversion regularisation:

- n = 1  -> very smooth transitions (strong smoothing)
- n = 2  -> moderate behaviour (often used as default)
- n = 3  -> sharper, more blocky structures

In this project we simply propagate n from the block file to element arrays,
and optionally allow a global override when injecting region values back into
a rho / block file.
