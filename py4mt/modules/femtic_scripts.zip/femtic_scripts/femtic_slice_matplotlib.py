#!/usr/bin/env python3
"""
femtic_slice_matplotlib.py

Compute and plot vertical resistivity slices (curtains) along arbitrary XY
polylines from FEMTIC element NPZ files using pure Matplotlib.

The NPZ file is expected to come from femtic_mesh_to_npz.py and to contain
at least:

    centroid            (nelem, 3)
    log10_resistivity   (nelem,)
    flag                (nelem,)  [optional, 1 = fixed]

Fixed elements (flag == 1) are ignored when present.

The slice is defined by an XY polyline (either from a CSV file or via
repeated --xy X Y arguments). Along this polyline, an arclength coordinate S
is constructed, and a regular grid in (S, Z) is sampled by inverse distance
weighting (IDW) in 3D. The result is then plotted with Matplotlib.

Author: Volker Rath (DIAS)
Created by ChatGPT (GPT-5 Thinking) on 2025-12-08
"""
from __future__ import annotations

from typing import Tuple
import numpy as np
import matplotlib.pyplot as plt


# ---------------------------------------------------------------------------
# Geometry helpers
# ---------------------------------------------------------------------------

def _build_s(points_xy: np.ndarray) -> np.ndarray:
    """
    Compute cumulative arclength along a polyline.

    Parameters
    ----------
    points_xy : ndarray, shape (m, 2)
        Polyline vertices [x, y] in order.

    Returns
    -------
    s : ndarray, shape (m,)
        Cumulative arclength coordinates for each vertex.
    """
    points_xy = np.asarray(points_xy, dtype=float)
    diffs = np.diff(points_xy, axis=0)
    seglen = np.sqrt(np.sum(diffs**2, axis=1))
    s = np.concatenate([[0.0], np.cumsum(seglen)])
    return s


def sample_polyline(points_xy: np.ndarray, ns: int) -> Tuple[np.ndarray, np.ndarray]:
    """
    Sample a polyline at ns evenly spaced arclength positions.

    Parameters
    ----------
    points_xy : ndarray, shape (m, 2)
        Polyline vertices.
    ns : int
        Number of sample points along the polyline.

    Returns
    -------
    S : ndarray, shape (ns,)
        Arclength coordinates of the samples.
    XY : ndarray, shape (ns, 2)
        Sampled XY coordinates.
    """
    points_xy = np.asarray(points_xy, dtype=float)
    if points_xy.shape[0] < 2:
        raise ValueError("Polyline must contain at least two vertices.")

    s = _build_s(points_xy)
    total = s[-1]
    if total <= 0.0:
        raise ValueError("Polyline length must be positive.")

    S = np.linspace(0.0, total, ns)
    XY = np.empty((ns, 2), dtype=float)

    for i, si in enumerate(S):
        j = np.searchsorted(s, si, side="right") - 1
        j = max(0, min(j, len(s) - 2))
        denom = max(s[j + 1] - s[j], 1e-12)
        t = (si - s[j]) / denom
        XY[i] = (1.0 - t) * points_xy[j] + t * points_xy[j + 1]

    return S, XY


# ---------------------------------------------------------------------------
# IDW interpolation
# ---------------------------------------------------------------------------

def _idw_point(
    q: np.ndarray,
    pts: np.ndarray,
    vals_log10: np.ndarray,
    power: float = 2.0,
    eps: float = 1e-6,
) -> float:
    """
    Interpolate a single 3D point using inverse distance weighting in log10 space.

    Parameters
    ----------
    q : ndarray, shape (3,)
        Query point [x, y, z].
    pts : ndarray, shape (n, 3)
        Data locations [x, y, z].
    vals_log10 : ndarray, shape (n,)
        Log10-space data values at pts.
    power : float, optional
        IDW power exponent.
    eps : float, optional
        Regularisation term added to squared distances.

    Returns
    -------
    value_log10 : float
        Interpolated value in log10 space.
    """
    d2 = np.sum((pts - q) ** 2, axis=1) + eps**2
    w = 1.0 / (d2 ** (power / 2.0))
    return float(np.sum(w * vals_log10) / np.sum(w))


def curtain_slice_idw(
    points_xy: np.ndarray,
    z_samples: np.ndarray,
    centroids: np.ndarray,
    vals_log10: np.ndarray,
    power: float = 2.0,
    ns: int = 301,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Compute a log10 curtain slice along an XY polyline using IDW.

    Parameters
    ----------
    points_xy : ndarray, shape (m, 2)
        Polyline vertices.
    z_samples : ndarray, shape (nz,)
        Depth samples.
    centroids : ndarray, shape (nelem, 3)
        Element centroids.
    vals_log10 : ndarray, shape (nelem,)
        Log10(resistivity) values at centroids.
    power : float, optional
        IDW power exponent.
    ns : int, optional
        Number of samples along the polyline.

    Returns
    -------
    S : ndarray, shape (ns,)
        Arclength coordinates along the curtain.
    Z : ndarray, shape (nz,)
        Depth samples.
    V_log10 : ndarray, shape (nz, ns)
        Interpolated values in log10 space.
    XY : ndarray, shape (ns, 2)
        XY coordinates of the curtain samples.
    """
    centroids = np.asarray(centroids, dtype=float)
    vals_log10 = np.asarray(vals_log10, dtype=float)
    Z = np.asarray(z_samples, dtype=float)

    S, XY = sample_polyline(points_xy, ns)
    V = np.empty((Z.size, S.size), dtype=float)

    for j, (x, y) in enumerate(XY):
        for i, z in enumerate(Z):
            q = np.array([x, y, z], dtype=float)
            V[i, j] = _idw_point(q, centroids, vals_log10, power=power)

    return S, Z, V, XY


# ---------------------------------------------------------------------------
# Matplotlib plotting
# ---------------------------------------------------------------------------

def plot_curtain_matplotlib(
    S: np.ndarray,
    Z: np.ndarray,
    V: np.ndarray,
    *,
    logscale: bool = True,
    z_positive_down: bool = True,
    cmap: str = "viridis",
    vmin: float | None = None,
    vmax: float | None = None,
    title: str = "Curtain slice",
) -> tuple[plt.Figure, plt.Axes]:
    """
    Plot a curtain slice using Matplotlib.

    Parameters
    ----------
    S : ndarray, shape (ns,)
        Arclength coordinates along the slice.
    Z : ndarray, shape (nz,)
        Depth samples.
    V : ndarray, shape (nz, ns)
        Values for the slice. If logscale is True, V is interpreted as
        linear resistivity [Ω·m] and plotted as log10(V).
    logscale : bool, optional
        If True, color scale is in log10(ρ). If False, in linear ρ.
    z_positive_down : bool, optional
        If True, depth increases downwards.
    cmap : str, optional
        Colormap name.
    vmin, vmax : float, optional
        Color limits. If None, determined automatically.
    title : str, optional
        Figure title.

    Returns
    -------
    fig, ax : Figure, Axes
        Matplotlib figure and axes.
    """
    S = np.asarray(S, dtype=float)
    Z = np.asarray(Z, dtype=float)
    V = np.asarray(V, dtype=float)

    # Prepare data for imshow; extent maps array indices to physical coordinates
    if logscale:
        data = np.log10(np.clip(V, 1e-30, np.inf))
        cbar_label = "log10(ρ) [Ω·m]"
    else:
        data = V
        cbar_label = "ρ [Ω·m]"

    fig, ax = plt.subplots(figsize=(6.0, 4.0))

    # Note: imshow expects [row, col] -> [y, x]
    # We take S along x, Z along y.
    # For z_positive_down, we flip the extent in y.
    if z_positive_down:
        extent = [S.min(), S.max(), Z.max(), Z.min()]
    else:
        extent = [S.min(), S.max(), Z.min(), Z.max()]

    im = ax.imshow(
        data,
        extent=extent,
        origin="upper" if z_positive_down else "lower",
        aspect="auto",
        cmap=cmap,
        vmin=vmin,
        vmax=vmax,
    )

    ax.set_xlabel("Distance along slice S")
    ax.set_ylabel("Depth z")
    ax.set_title(title)

    cbar = fig.colorbar(im, ax=ax)
    cbar.set_label(cbar_label)

    ax.grid(False)
    fig.tight_layout()
    return fig, ax


# ---------------------------------------------------------------------------
# High-level wrapper & CLI
# ---------------------------------------------------------------------------

def femtic_slice_from_npz_matplotlib(
    npz_path: str,
    *,
    polyline_xy: np.ndarray | None = None,
    polyline_csv: str | None = None,
    zmin: float,
    zmax: float,
    nz: int = 201,
    ns: int = 301,
    power: float = 2.0,
    logscale: bool = True,
    z_positive_down: bool = True,
    cmap: str = "viridis",
    vmin: float | None = None,
    vmax: float | None = None,
    out_npz: str | None = None,
    out_csv: str | None = None,
    out_png: str | None = None,
    title: str = "Curtain slice",
) -> None:
    """
    High-level helper: compute curtain from FEMTIC NPZ and plot with Matplotlib.

    Parameters
    ----------
    npz_path : str
        NPZ file with 'centroid', 'log10_resistivity', and optional 'flag'.
    polyline_xy : ndarray, shape (m, 2), optional
        Polyline vertices; ignored if polyline_csv is given.
    polyline_csv : str, optional
        CSV file with columns x,y listing polyline vertices.
    zmin, zmax : float
        Depth range for slice.
    nz : int, optional
        Number of depth samples.
    ns : int, optional
        Number of samples along the polyline.
    power : float, optional
        IDW power exponent.
    logscale : bool, optional
        If True, plot log10(ρ). If False, plot ρ.
    z_positive_down : bool, optional
        If True, depth increases downwards.
    cmap : str, optional
        Colormap name.
    vmin, vmax : float, optional
        Color limits.
    out_npz : str, optional
        If given, save curtain arrays (S, Z, V_log10, XY) to NPZ.
    out_csv : str, optional
        If given, save curtain data (s, z, log10_rho) to CSV.
    out_png : str, optional
        If given, save Matplotlib figure to PNG.
    title : str, optional
        Plot title.
    """
    import csv

    data = np.load(npz_path)
    if "centroid" not in data or "log10_resistivity" not in data:
        raise KeyError("NPZ must contain 'centroid' and 'log10_resistivity'.")

    centroids = data["centroid"]
    vals_log10 = data["log10_resistivity"]

    # Drop fixed elements if flag is present
    if "flag" in data:
        mask = data["flag"] != 1
        centroids = centroids[mask]
        vals_log10 = vals_log10[mask]

    # Polyline
    if polyline_csv is not None:
        pts = []
        with open(polyline_csv, "r") as f:
            r = csv.reader(f)
            for row in r:
                if not row:
                    continue
                try:
                    x = float(row[0])
                    y = float(row[1])
                except Exception:
                    continue
                pts.append([x, y])
        if len(pts) < 2:
            raise ValueError("Polyline CSV must contain at least two vertices.")
        poly_xy = np.asarray(pts, dtype=float)
    else:
        if polyline_xy is None or polyline_xy.shape[0] < 2:
            raise ValueError("Provide at least two polyline vertices via polyline_xy.")
        poly_xy = np.asarray(polyline_xy, dtype=float)

    Z = np.linspace(zmin, zmax, nz)
    S, Z, V_log10, XY = curtain_slice_idw(poly_xy, Z, centroids, vals_log10,
                                          power=power, ns=ns)

    # Save curtain if requested
    if out_npz is not None:
        np.savez_compressed(out_npz, S=S, Z=Z, V_log10=V_log10, XY=XY)
        print("Saved curtain NPZ:", out_npz)

    if out_csv is not None:
        with open(out_csv, "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["s", "z", "log10_rho"])
            for j, s in enumerate(S):
                for i, z in enumerate(Z):
                    w.writerow([s, z, V_log10[i, j]])
        print("Saved curtain CSV:", out_csv)

    # For plotting, choose linear or log-space fields
    if logscale:
        V_plot = 10.0 ** V_log10  # convert to linear, colorbar in log10
    else:
        V_plot = 10.0 ** V_log10  # still linear; colorbar in linear space

    fig, ax = plot_curtain_matplotlib(
        S,
        Z,
        V_plot,
        logscale=logscale,
        z_positive_down=z_positive_down,
        cmap=cmap,
        vmin=vmin,
        vmax=vmax,
        title=title,
    )

    if out_png is not None:
        fig.savefig(out_png, dpi=200, bbox_inches="tight")
        print("Saved PNG:", out_png)
    else:
        try:
            plt.show()
        except Exception:
            pass


def main() -> None:
    """
    CLI entry point for computing & plotting FEMTIC slices with Matplotlib.

    Examples
    --------
    1) Polyline from CSV (columns x,y):

        python -m femtic_slice_matplotlib \\
            --npz femtic_model.npz \\
            --polyline-csv polyline.csv \\
            --zmin -2500 --zmax 0 --nz 201 --ns 301 \\
            --logscale --z-positive-down \\
            --out-npz curtain_slice.npz \\
            --out-png curtain_slice.png

    2) Polyline from command line:

        python -m femtic_slice_matplotlib \\
            --npz femtic_model.npz \\
            --xy 0 0 --xy 2000 0 --xy 3000 1000 \\
            --zmin -3000 --zmax 0 --nz 201 --ns 401 \\
            --logscale --z-positive-down
    """
    import argparse

    ap = argparse.ArgumentParser(
        description="Vertical FEMTIC slices along arbitrary XY polylines (Matplotlib)."
    )
    ap.add_argument("--npz", required=True, help="Element NPZ from femtic_mesh_to_npz.py.")
    ap.add_argument("--polyline-csv", help="CSV file with x,y columns for polyline vertices.")
    ap.add_argument(
        "--xy",
        action="append",
        nargs=2,
        type=float,
        metavar=("X", "Y"),
        help="Polyline vertex (X Y). Repeat to build polyline.",
    )
    ap.add_argument("--zmin", type=float, required=True, help="Minimum depth of slice.")
    ap.add_argument("--zmax", type=float, required=True, help="Maximum depth of slice.")
    ap.add_argument("--nz", type=int, default=201, help="Number of depth samples.")
    ap.add_argument("--ns", type=int, default=301, help="Number of samples along slice.")
    ap.add_argument("--power", type=float, default=2.0, help="IDW power exponent.")
    ap.add_argument("--logscale", action="store_true", help="Plot in log10(ρ).")
    ap.add_argument(
        "--z-positive-down",
        action="store_true",
        help="Use depth increasing downwards.",
    )
    ap.add_argument("--cmap", default="viridis", help="Matplotlib colormap name.")
    ap.add_argument("--vmin", type=float, default=None, help="Color scale minimum.")
    ap.add_argument("--vmax", type=float, default=None, help="Color scale maximum.")
    ap.add_argument("--out-npz", default=None, help="Optional output NPZ for curtain.")
    ap.add_argument("--out-csv", default=None, help="Optional output CSV for curtain.")
    ap.add_argument("--out-png", default=None, help="Optional PNG output for the plot.")
    ap.add_argument("--title", default="Curtain slice", help="Plot title.")
    args = ap.parse_args()

    # Determine polyline specification
    polyline_xy = None
    if args.polyline_csv is None:
        if not args.xy or len(args.xy) < 2:
            raise ValueError(
                "Provide a polyline via --polyline-csv or at least two --xy X Y pairs."
            )
        polyline_xy = np.asarray([[x, y] for x, y in args.xy], dtype=float)

    femtic_slice_from_npz_matplotlib(
        npz_path=args.npz,
        polyline_xy=polyline_xy,
        polyline_csv=args.polyline_csv,
        zmin=args.zmin,
        zmax=args.zmax,
        nz=args.nz,
        ns=args.ns,
        power=args.power,
        logscale=args.logscale,
        z_positive_down=args.z_positive_down,
        cmap=args.cmap,
        vmin=args.vmin,
        vmax=args.vmax,
        out_npz=args.out_npz,
        out_csv=args.out_csv,
        out_png=args.out_png,
        title=args.title,
    )


if __name__ == "__main__":
    main()
