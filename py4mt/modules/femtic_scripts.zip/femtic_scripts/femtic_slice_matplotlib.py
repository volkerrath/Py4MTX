#!/usr/bin/env python3
"""
femtic_slice_matplotlib.py

Vertical FEMTIC resistivity slices (curtains) from NPZ, pure Matplotlib, with
pluggable interpolation (idw / nearest / rbf).

NPZ is expected to contain at least:
    centroid            (nelem, 3)
    log10_resistivity   (nelem,)
    flag                (nelem,)  [optional, 1 = fixed]

Author: Volker Rath (DIAS)
Created by ChatGPT (GPT-5 Thinking) on 2025-12-08
"""
from __future__ import annotations

from typing import Tuple
import numpy as np
import matplotlib.pyplot as plt


def _build_s(points_xy: np.ndarray) -> np.ndarray:
    """Cumulative arclength along a polyline."""
    points_xy = np.asarray(points_xy, dtype=float)
    diffs = np.diff(points_xy, axis=0)
    seglen = np.sqrt(np.sum(diffs**2, axis=1))
    return np.concatenate([[0.0], np.cumsum(seglen)])


def sample_polyline(points_xy: np.ndarray, ns: int) -> Tuple[np.ndarray, np.ndarray]:
    """Sample a polyline at ns equally spaced arclength positions."""
    points_xy = np.asarray(points_xy, dtype=float)
    if points_xy.shape[0] < 2:
        raise ValueError("Polyline must contain at least two vertices.")
    s = _build_s(points_xy)
    total = s[-1]
    if total <= 0.0:
        raise ValueError("Polyline length must be positive.")
    S = np.linspace(0.0, total, ns)
    XY = np.empty((ns, 2), dtype=float)
    for i, si in enumerate(S):
        j = np.searchsorted(s, si, side="right") - 1
        j = max(0, min(j, len(s) - 2))
        denom = max(s[j + 1] - s[j], 1e-12)
        t = (si - s[j]) / denom
        XY[i] = (1.0 - t) * points_xy[j] + t * points_xy[j + 1]
    return S, XY


def _idw_point(q: np.ndarray, pts: np.ndarray, vals: np.ndarray,
               power: float = 2.0, eps: float = 1e-6) -> float:
    """Inverse distance weighting in 3D for a single point (log10-space)."""
    d2 = np.sum((pts - q) ** 2, axis=1) + eps**2
    w = 1.0 / (d2 ** (power / 2.0))
    return float(np.sum(w * vals) / np.sum(w))


def curtain_slice_idw(points_xy: np.ndarray, z_samples: np.ndarray,
                      centroids: np.ndarray, vals_log10: np.ndarray,
                      power: float = 2.0, ns: int = 301
                      ) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Curtain slice using 3D IDW on log10 values."""
    centroids = np.asarray(centroids, dtype=float)
    vals_log10 = np.asarray(vals_log10, dtype=float)
    Z = np.asarray(z_samples, dtype=float)
    S, XY = sample_polyline(points_xy, ns)
    V = np.empty((Z.size, S.size), dtype=float)
    for j, (x, y) in enumerate(XY):
        for i, z in enumerate(Z):
            V[i, j] = _idw_point(np.array([x, y, z], float),
                                 centroids, vals_log10, power=power)
    return S, Z, V, XY


def curtain_slice_nearest(points_xy: np.ndarray, z_samples: np.ndarray,
                          centroids: np.ndarray, vals_log10: np.ndarray,
                          ns: int = 301
                          ) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Curtain slice using nearest neighbour in 3D (no smoothing)."""
    centroids = np.asarray(centroids, dtype=float)
    vals_log10 = np.asarray(vals_log10, dtype=float)
    Z = np.asarray(z_samples, dtype=float)
    S, XY = sample_polyline(points_xy, ns)
    V = np.empty((Z.size, S.size), dtype=float)
    try:
        from scipy.spatial import cKDTree  # type: ignore[attr-defined]
        tree = cKDTree(centroids)
        queries = np.stack(
            [np.repeat(XY[:, 0], Z.size),
             np.repeat(XY[:, 1], Z.size),
             np.tile(Z, XY.shape[0])],
            axis=1,
        )
        _, idx = tree.query(queries)
        V[:] = vals_log10[idx].reshape(Z.size, XY.shape[0], order="F")
    except Exception:
        for j, (x, y) in enumerate(XY):
            for i, z in enumerate(Z):
                q = np.array([x, y, z], float)
                d2 = np.sum((centroids - q) ** 2, axis=1)
                k = int(np.argmin(d2))
                V[i, j] = vals_log10[k]
    return S, Z, V, XY


def curtain_slice_rbf(points_xy: np.ndarray, z_samples: np.ndarray,
                      centroids: np.ndarray, vals_log10: np.ndarray,
                      ns: int = 301
                      ) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Curtain slice using 3D RBF interpolation (SciPy)."""
    try:
        from scipy.interpolate import RBFInterpolator  # type: ignore[attr-defined]
    except Exception as exc:  # pragma: no cover
        raise ImportError(
            "RBF interpolation requires scipy.interpolate.RBFInterpolator."
        ) from exc
    centroids = np.asarray(centroids, dtype=float)
    vals_log10 = np.asarray(vals_log10, dtype=float)
    Z = np.asarray(z_samples, dtype=float)
    S, XY = sample_polyline(points_xy, ns)
    rbf = RBFInterpolator(centroids, vals_log10, kernel="thin_plate_spline")
    XX = np.repeat(XY[:, 0][None, :], Z.size, axis=0)
    YY = np.repeat(XY[:, 1][None, :], Z.size, axis=0)
    ZZ = np.repeat(Z[:, None], XY.shape[0], axis=1)
    Q = np.column_stack([XX.ravel(), YY.ravel(), ZZ.ravel()])
    V_flat = rbf(Q)
    V = V_flat.reshape(Z.size, XY.shape[0])
    return S, Z, V, XY


def curtain_slice(points_xy: np.ndarray, z_samples: np.ndarray,
                  centroids: np.ndarray, vals_log10: np.ndarray,
                  *, interp: str = "idw", power: float = 2.0, ns: int = 301
                  ) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Dispatch curtain interpolation according to interp method."""
    interp = interp.lower()
    if interp == "idw":
        return curtain_slice_idw(points_xy, z_samples, centroids, vals_log10,
                                 power=power, ns=ns)
    if interp == "nearest":
        return curtain_slice_nearest(points_xy, z_samples, centroids, vals_log10,
                                     ns=ns)
    if interp == "rbf":
        return curtain_slice_rbf(points_xy, z_samples, centroids, vals_log10,
                                 ns=ns)
    raise ValueError(f"Unknown interp '{interp}' (expected idw, nearest, rbf).")


def plot_curtain_matplotlib(S: np.ndarray, Z: np.ndarray, V: np.ndarray,
                            *, logscale: bool = True,
                            z_positive_down: bool = True,
                            cmap: str = "viridis",
                            vmin: float | None = None,
                            vmax: float | None = None,
                            title: str = "Curtain slice"
                            ) -> tuple[plt.Figure, plt.Axes]:
    """Plot a curtain slice using Matplotlib."""
    S = np.asarray(S, float)
    Z = np.asarray(Z, float)
    V = np.asarray(V, float)
    if logscale:
        data = np.log10(np.clip(V, 1e-30, np.inf))
        cbar_label = "log10(ρ) [Ω·m]"
    else:
        data = V
        cbar_label = "ρ [Ω·m]"
    fig, ax = plt.subplots(figsize=(6.0, 4.0))
    if z_positive_down:
        extent = [S.min(), S.max(), Z.max(), Z.min()]
        origin = "upper"
    else:
        extent = [S.min(), S.max(), Z.min(), Z.max()]
        origin = "lower"
    im = ax.imshow(
        data,
        extent=extent,
        origin=origin,
        aspect="auto",
        cmap=cmap,
        vmin=vmin,
        vmax=vmax,
    )
    ax.set_xlabel("Distance along slice S")
    ax.set_ylabel("Depth z")
    ax.set_title(title)
    cbar = fig.colorbar(im, ax=ax)
    cbar.set_label(cbar_label)
    fig.tight_layout()
    return fig, ax


def femtic_slice_from_npz_matplotlib(
    npz_path: str,
    *,
    polyline_xy: np.ndarray | None = None,
    polyline_csv: str | None = None,
    zmin: float,
    zmax: float,
    nz: int = 201,
    ns: int = 301,
    power: float = 2.0,
    interp: str = "idw",
    logscale: bool = True,
    z_positive_down: bool = True,
    cmap: str = "viridis",
    vmin: float | None = None,
    vmax: float | None = None,
    out_npz: str | None = None,
    out_csv: str | None = None,
    out_png: str | None = None,
    title: str = "Curtain slice",
) -> None:
    """High-level helper: build & plot curtain from FEMTIC NPZ."""
    import csv

    data = np.load(npz_path)
    if "centroid" not in data or "log10_resistivity" not in data:
        raise KeyError("NPZ must contain 'centroid' and 'log10_resistivity'.")
    centroids = data["centroid"]
    vals_log10 = data["log10_resistivity"]
    if "flag" in data:
        mask = data["flag"] != 1
        centroids = centroids[mask]
        vals_log10 = vals_log10[mask]

    if polyline_csv is not None:
        pts = []
        with open(polyline_csv, "r") as f:
            lines=f.readlines()
            for line in lines:
                xy = np.fromstring(line, dtype=float, sep=',')
                x = float(xy[0])
                y = float(xy[1])
                pts.append([x, y])
        print(pts)
        if len(pts) < 2:
            raise ValueError("Polyline CSV must contain at least two vertices.")
        poly_xy = np.asarray(pts, dtype=float)
    else:
        if polyline_xy is None or polyline_xy.shape[0] < 2:
            raise ValueError("Provide at least two polyline vertices via polyline_xy.")
        poly_xy = np.asarray(polyline_xy, dtype=float)

    Z = np.linspace(zmin, zmax, nz)
    S, Z, V_log10, XY = curtain_slice(
        poly_xy,
        Z,
        centroids,
        vals_log10,
        interp=interp,
        power=power,
        ns=ns,
    )

    if out_npz is not None:
        np.savez_compressed(out_npz, S=S, Z=Z, V_log10=V_log10, XY=XY, interp=interp)
        print("Saved curtain NPZ:", out_npz)

    if out_csv is not None:
        with open(out_csv, "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["s", "z", "log10_rho"])
            for j, s in enumerate(S):
                for i, z in enumerate(Z):
                    w.writerow([s, z, V_log10[i, j]])
        print("Saved curtain CSV:", out_csv)

    V_plot = 10.0 ** V_log10
    fig, ax = plot_curtain_matplotlib(
        S,
        Z,
        V_plot,
        logscale=logscale,
        z_positive_down=z_positive_down,
        cmap=cmap,
        vmin=vmin,
        vmax=vmax,
        title=title,
    )

    if out_png is not None:
        fig.savefig(out_png, dpi=200, bbox_inches="tight")
        print("Saved PNG:", out_png)
    else:
        try:
            plt.show()
        except Exception:
            pass


def main() -> None:
    """CLI entry point for vertical FEMTIC slices."""
    import argparse

    ap = argparse.ArgumentParser(
        description="Vertical FEMTIC slices along arbitrary XY polylines (Matplotlib)."
    )
    ap.add_argument("--npz", required=True, help="Element NPZ from femtic_mesh_to_npz.py.")
    ap.add_argument("--polyline-csv", help="CSV file with x,y columns for polyline vertices.")
    ap.add_argument(
        "--xy",
        action="append",
        nargs=2,
        type=float,
        metavar=("X", "Y"),
        help="Polyline vertex (X Y). Repeat to build polyline.",
    )
    ap.add_argument("--zmin", type=float, required=True, help="Minimum depth of slice.")
    ap.add_argument("--zmax", type=float, required=True, help="Maximum depth of slice.")
    ap.add_argument("--nz", type=int, default=201, help="Number of depth samples.")
    ap.add_argument("--ns", type=int, default=301, help="Number of samples along slice.")
    ap.add_argument("--power", type=float, default=2.0, help="IDW power exponent (interp='idw').")
    ap.add_argument(
        "--interp",
        choices=["idw", "nearest", "rbf"],
        default="idw",
        help="Interpolation method.",
    )
    ap.add_argument("--logscale", action="store_true", help="Plot in log10(ρ).")
    ap.add_argument(
        "--z-positive-down",
        action="store_true",
        help="Depth increases downwards in plot.",
    )
    ap.add_argument("--cmap", default="viridis", help="Matplotlib colormap.")
    ap.add_argument("--vmin", type=float, default=None, help="Color scale minimum.")
    ap.add_argument("--vmax", type=float, default=None, help="Color scale maximum.")
    ap.add_argument("--out-npz", default=None, help="Optional output NPZ for curtain.")
    ap.add_argument("--out-csv", default=None, help="Optional output CSV for curtain.")
    ap.add_argument("--out-png", default=None, help="Optional PNG output for the plot.")
    ap.add_argument("--title", default="Curtain slice", help="Plot title.")
    args = ap.parse_args()

    polyline_xy = None
    if args.polyline_csv is None:
        if not args.xy or len(args.xy) < 2:
            raise ValueError(
                "Provide a polyline via --polyline-csv or at least two --xy X Y pairs."
            )
        polyline_xy = np.asarray([[x, y] for x, y in args.xy], dtype=float)

    femtic_slice_from_npz_matplotlib(
        npz_path=args.npz,
        polyline_xy=polyline_xy,
        polyline_csv=args.polyline_csv,
        zmin=args.zmin,
        zmax=args.zmax,
        nz=args.nz,
        ns=args.ns,
        power=args.power,
        interp=args.interp,
        logscale=args.logscale,
        z_positive_down=args.z_positive_down,
        cmap=args.cmap,
        vmin=args.vmin,
        vmax=args.vmax,
        out_npz=args.out_npz,
        out_csv=args.out_csv,
        out_png=args.out_png,
        title=args.title,
    )


if __name__ == "__main__":
    main()
