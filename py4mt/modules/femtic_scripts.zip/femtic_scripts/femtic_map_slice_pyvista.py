#!/usr/bin/env python3
"""
femtic_map_slice_pyvista.py

Horizontal FEMTIC resistivity slices (maps) at fixed depth using PyVista.

This script mirrors femtic_map_slice_matplotlib: it selects centroids in a
depth window around z0, interpolates onto a regular (x, y) grid using one
of:

    interp = 'idw'      (inverse-distance weighting)
    interp = 'nearest'  (nearest neighbour)
    interp = 'rbf'      (Radial Basis Function, SciPy)

and builds a 2-D PyVista StructuredGrid at constant depth z0.

Cell data:
    log10_rho  (log10_resistivity)
    rho        (10**log10_rho)

Author: Volker Rath (DIAS)
Created by ChatGPT (GPT-5 Thinking) on 2025-12-08
"""
from __future__ import annotations

from typing import Tuple
import numpy as np


def _select_depth_window(
    centroids: np.ndarray,
    vals_log10: np.ndarray,
    z0: float,
    dz: float,
) -> Tuple[np.ndarray, np.ndarray]:
    """Select centroids and log10 values within a vertical window around z0."""
    centroids = np.asarray(centroids, dtype=float)
    vals_log10 = np.asarray(vals_log10, dtype=float)
    z = centroids[:, 2]
    half = dz / 2.0
    mask = (z >= z0 - half) & (z <= z0 + half)
    if not np.any(mask):
        raise ValueError("No centroids found in the depth window around z0.")
    pts_xy = centroids[mask, :2]
    vals_sel = vals_log10[mask]
    return pts_xy, vals_sel


def _idw_grid_2d(
    x: np.ndarray,
    y: np.ndarray,
    pts_xy: np.ndarray,
    vals_log10: np.ndarray,
    power: float = 2.0,
    eps: float = 1e-6,
) -> np.ndarray:
    """2D IDW on regular (x, y) grid (log10-space)."""
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    pts_xy = np.asarray(pts_xy, float)
    vals_log10 = np.asarray(vals_log10, float)
    nx = x.size
    ny = y.size
    V = np.empty((ny, nx), float)
    px = pts_xy[:, 0]
    py = pts_xy[:, 1]
    for j in range(ny):
        yj = y[j]
        dy2 = (py - yj) ** 2
        for i in range(nx):
            xi = x[i]
            d2 = (px - xi) ** 2 + dy2 + eps**2
            w = 1.0 / (d2 ** (power / 2.0))
            V[j, i] = float(np.sum(w * vals_log10) / np.sum(w))
    return V


def _nearest_grid_2d(
    x: np.ndarray,
    y: np.ndarray,
    pts_xy: np.ndarray,
    vals_log10: np.ndarray,
) -> np.ndarray:
    """2D nearest neighbour interpolation on regular grid."""
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    pts_xy = np.asarray(pts_xy, float)
    vals_log10 = np.asarray(vals_log10, float)
    nx = x.size
    ny = y.size
    V = np.empty((ny, nx), float)
    try:
        from scipy.spatial import cKDTree  # type: ignore[attr-defined]
        tree = cKDTree(pts_xy)
        XX, YY = np.meshgrid(x, y)
        Q = np.column_stack([XX.ravel(), YY.ravel()])
        _, idx = tree.query(Q)
        V[:] = vals_log10[idx].reshape(ny, nx)
    except Exception:
        px = pts_xy[:, 0]
        py = pts_xy[:, 1]
        for j in range(ny):
            yj = y[j]
            dy2 = (py - yj) ** 2
            for i in range(nx):
                xi = x[i]
                d2 = (px - xi) ** 2 + dy2
                k = int(np.argmin(d2))
                V[j, i] = vals_log10[k]
    return V


def _rbf_grid_2d(
    x: np.ndarray,
    y: np.ndarray,
    pts_xy: np.ndarray,
    vals_log10: np.ndarray,
) -> np.ndarray:
    """2D RBF interpolation on regular grid (SciPy)."""
    try:
        from scipy.interpolate import RBFInterpolator  # type: ignore[attr-defined]
    except Exception as exc:  # pragma: no cover
        raise ImportError(
            "RBF interpolation requires scipy.interpolate.RBFInterpolator."
        ) from exc
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    pts_xy = np.asarray(pts_xy, float)
    vals_log10 = np.asarray(vals_log10, float)
    rbf = RBFInterpolator(pts_xy, vals_log10, kernel="thin_plate_spline")
    XX, YY = np.meshgrid(x, y)
    Q = np.column_stack([XX.ravel(), YY.ravel()])
    V_flat = rbf(Q)
    return V_flat.reshape(y.size, x.size)


def _grid_2d(
    x: np.ndarray,
    y: np.ndarray,
    pts_xy: np.ndarray,
    vals_log10: np.ndarray,
    *,
    interp: str = "idw",
    power: float = 2.0,
) -> np.ndarray:
    """Dispatch 2D interpolation on a regular grid."""
    interp = interp.lower()
    if interp == "idw":
        return _idw_grid_2d(x, y, pts_xy, vals_log10, power=power)
    if interp == "nearest":
        return _nearest_grid_2d(x, y, pts_xy, vals_log10)
    if interp == "rbf":
        return _rbf_grid_2d(x, y, pts_xy, vals_log10)
    raise ValueError(f"Unknown interp '{interp}' (expected idw, nearest, rbf).")


def build_map_grid_from_npz(
    npz_path: str,
    *,
    z0: float,
    dz: float,
    nx: int = 200,
    ny: int = 200,
    xmin: float | None = None,
    xmax: float | None = None,
    ymin: float | None = None,
    ymax: float | None = None,
    interp: str = "idw",
    power: float = 2.0,
) -> "pyvista.StructuredGrid":
    """Build a PyVista StructuredGrid for a horizontal slice at depth z0."""
    try:
        import pyvista as pv
    except Exception as exc:  # pragma: no cover
        raise ImportError("pyvista is required for map plotting.") from exc

    data = np.load(npz_path)
    if "centroid" not in data or "log10_resistivity" not in data:
        raise KeyError("NPZ must contain 'centroid' and 'log10_resistivity'.")

    centroids = data["centroid"]
    vals_log10 = data["log10_resistivity"]
    if "flag" in data:
        mask = data["flag"] != 1
        centroids = centroids[mask]
        vals_log10 = vals_log10[mask]

    pts_xy, vals_sel = _select_depth_window(centroids, vals_log10, z0=z0, dz=dz)

    if xmin is None:
        xmin = float(pts_xy[:, 0].min())
    if xmax is None:
        xmax = float(pts_xy[:, 0].max())
    if ymin is None:
        ymin = float(pts_xy[:, 1].min())
    if ymax is None:
        ymax = float(pts_xy[:, 1].max())

    dx = xmax - xmin
    dy = ymax - ymin
    xmin -= 0.02 * dx
    xmax += 0.02 * dx
    ymin -= 0.02 * dy
    ymax += 0.02 * dy

    x = np.linspace(xmin, xmax, nx)
    y = np.linspace(ymin, ymax, ny)
    V_log10 = _grid_2d(x, y, pts_xy, vals_sel, interp=interp, power=power)
    X, Y = np.meshgrid(x, y)

    # Build StructuredGrid in (x, y, z0)
    Z = np.full_like(X, z0, dtype=float)
    X3 = X[:, :, None]
    Y3 = Y[:, :, None]
    Z3 = Z[:, :, None]

    import pyvista as pv

    grid = pv.StructuredGrid(X3, Y3, Z3)
    grid["log10_rho"] = V_log10.ravel(order="C")
    grid["rho"] = (10.0 ** V_log10).ravel(order="C")
    return grid


def main() -> None:
    """CLI entry point for PyVista horizontal map slices."""
    import argparse
    import pyvista as pv

    ap = argparse.ArgumentParser(
        description="Horizontal FEMTIC resistivity slices at fixed depth using PyVista."
    )
    ap.add_argument("--npz", required=True, help="Element NPZ from femtic_mesh_to_npz.py.")
    ap.add_argument("--z0", type=float, required=True, help="Central depth of slice.")
    ap.add_argument("--dz", type=float, required=True, help="Thickness of vertical window around z0.")
    ap.add_argument("--nx", type=int, default=200, help="Number of grid points in x.")
    ap.add_argument("--ny", type=int, default=200, help="Number of grid points in y.")
    ap.add_argument("--xmin", type=float, default=None, help="Minimum x for grid.")
    ap.add_argument("--xmax", type=float, default=None, help="Maximum x for grid.")
    ap.add_argument("--ymin", type=float, default=None, help="Minimum y for grid.")
    ap.add_argument("--ymax", type=float, default=None, help="Maximum y for grid.")
    ap.add_argument(
        "--interp",
        choices=["idw", "nearest", "rbf"],
        default="idw",
        help="Interpolation method.",
    )
    ap.add_argument("--power", type=float, default=2.0, help="IDW power exponent (interp='idw').")
    ap.add_argument("--out-vtk", default=None, help="Optional output .vts/.vtk file.")
    ap.add_argument(
        "--no-show",
        action="store_true",
        help="Do not open interactive PyVista window.",
    )
    args = ap.parse_args()

    grid = build_map_grid_from_npz(
        args.npz,
        z0=args.z0,
        dz=args.dz,
        nx=args.nx,
        ny=args.ny,
        xmin=args.xmin,
        xmax=args.xmax,
        ymin=args.ymin,
        ymax=args.ymax,
        interp=args.interp,
        power=args.power,
    )

    if args.out_vtk is not None:
        grid.save(args.out_vtk)
        print("Saved map grid to:", args.out_vtk)

    if not args.no_show:
        grid.plot(
            scalars="log10_rho",
            cmap="viridis",
        )


if __name__ == "__main__":  # pragma: no cover
    main()
