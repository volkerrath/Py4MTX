"""
femtic_polyline_slice.py

Compute a vertical curtain slice of resistivity along an XY polyline using
inverse-distance weighting on FEMTIC element centroids stored in an NPZ file.
Optional visualisation is done with PyVista.

Author: Volker Rath (DIAS)
Created by ChatGPT (GPT-5 Thinking) on 2025-12-07
"""
from __future__ import annotations

from typing import Tuple
import numpy as np


def _build_s(points_xy: np.ndarray) -> np.ndarray:
    """
    Compute cumulative arclength along the polyline.

    Parameters
    ----------
    points_xy : ndarray, shape (m, 2)
        Polyline vertices [x, y] in order.

    Returns
    -------
    s : ndarray, shape (m,)
        Cumulative arclength coordinates for each vertex.
    """
    diffs = np.diff(points_xy, axis=0)
    seglen = np.sqrt(np.sum(diffs**2, axis=1))
    s = np.concatenate([[0.0], np.cumsum(seglen)])
    return s


def sample_polyline(points_xy: np.ndarray, ns: int) -> Tuple[np.ndarray, np.ndarray]:
    """
    Sample a polyline at ns evenly spaced arclength positions.

    Parameters
    ----------
    points_xy : ndarray, shape (m, 2)
        Polyline vertices.
    ns : int
        Number of sample points along the polyline.

    Returns
    -------
    S : ndarray, shape (ns,)
        Arclength coordinates of the samples.
    XY : ndarray, shape (ns, 2)
        Sampled XY coordinates.
    """
    s = _build_s(points_xy)
    total = s[-1]
    if total <= 0.0:
        raise ValueError("Polyline length must be positive.")

    S = np.linspace(0.0, total, ns)
    XY = np.empty((ns, 2), dtype=float)

    for i, si in enumerate(S):
        j = np.searchsorted(s, si, side="right") - 1
        j = max(0, min(j, len(s) - 2))
        denom = max(s[j + 1] - s[j], 1e-12)
        t = (si - s[j]) / denom
        XY[i] = (1.0 - t) * points_xy[j] + t * points_xy[j + 1]

    return S, XY


def _idw_point(
    q: np.ndarray,
    pts: np.ndarray,
    vals_log10: np.ndarray,
    power: float = 2.0,
    eps: float = 1e-6,
) -> float:
    """
    Interpolate a single 3D point using IDW in log10 space.

    Parameters
    ----------
    q : ndarray, shape (3,)
        Query point [x, y, z].
    pts : ndarray, shape (n, 3)
        Data locations [x, y, z].
    vals_log10 : ndarray, shape (n,)
        Log10-space data values at pts.
    power : float, optional
        IDW power exponent.
    eps : float, optional
        Regularisation term added to squared distances.

    Returns
    -------
    value_log10 : float
        Interpolated value in log10 space.
    """
    d2 = np.sum((pts - q) ** 2, axis=1) + eps**2
    w = 1.0 / (d2 ** (power / 2.0))
    return float(np.sum(w * vals_log10) / np.sum(w))


def curtain_slice_idw(
    points_xy: np.ndarray,
    z_samples: np.ndarray,
    centroids: np.ndarray,
    vals_log10: np.ndarray,
    power: float = 2.0,
    ns: int = 301,
):
    """
    Compute a log10 curtain slice along an XY polyline using IDW.

    Parameters
    ----------
    points_xy : ndarray, shape (m, 2)
        Polyline vertices.
    z_samples : ndarray, shape (nz,)
        Depth samples.
    centroids : ndarray, shape (nelem, 3)
        Element centroids.
    vals_log10 : ndarray, shape (nelem,)
        Log10(resistivity) values at centroids.
    power : float, optional
        IDW power exponent.
    ns : int, optional
        Number of samples along the polyline.

    Returns
    -------
    S : ndarray, shape (ns,)
        Arclength coordinates along the curtain.
    Z : ndarray, shape (nz,)
        Depth samples.
    V_log10 : ndarray, shape (nz, ns)
        Interpolated values in log10 space.
    XY : ndarray, shape (ns, 2)
        XY coordinates of the curtain samples.
    """
    S, XY = sample_polyline(points_xy, ns)
    Z = np.array(z_samples, dtype=float)
    V = np.empty((Z.size, S.size), dtype=float)

    for j, (x, y) in enumerate(XY):
        for i, z in enumerate(Z):
            q = np.array([x, y, z], dtype=float)
            V[i, j] = _idw_point(q, centroids, vals_log10, power=power)

    return S, Z, V, XY


def plot_curtain_pyvista(
    S,
    Z,
    V,
    XY,
    *,
    cmap: str = "viridis",
    logscale: bool = True,
    title: str = "Curtain slice",
):
    """
    Plot a curtain slice as a PyVista StructuredGrid.

    Parameters
    ----------
    S : ndarray, shape (ns,)
        Arclength coordinates (used only for labelling).
    Z : ndarray, shape (nz,)
        Depth samples.
    V : ndarray, shape (nz, ns)
        Values in linear or log10 space.
    XY : ndarray, shape (ns, 2)
        XY coordinates along curtain.
    cmap : str, optional
        Colormap name.
    logscale : bool, optional
        If True, V is interpreted as linear values and log10(V) is plotted.
    title : str, optional
        Plot title.

    Returns
    -------
    plotter : pyvista.Plotter
        The PyVista plotter instance.
    grid : pyvista.StructuredGrid
        The structured grid representing the curtain.
    """
    try:
        import pyvista as pv
    except Exception as exc:  # pragma: no cover - optional dependency
        raise ImportError("PyVista is required for plotting.") from exc

    ns = S.size
    nz = Z.size

    X = np.repeat(XY[:, 0][None, :], nz, axis=0)
    Y = np.repeat(XY[:, 1][None, :], nz, axis=0)
    ZZ = np.repeat(Z[:, None], ns, axis=1)

    grid = pv.StructuredGrid(X.astype(float), Y.astype(float), ZZ.astype(float))

    if logscale:
        scalars = np.log10(np.clip(V, 1e-30, np.inf)).ravel(order="C")
        grid["log10_rho"] = scalars
        scal_name = "log10_rho"
        bar_title = "log10(ρ)"
    else:
        scalars = V.ravel(order="C")
        grid["rho"] = scalars
        scal_name = "rho"
        bar_title = "ρ (Ω·m)"

    p = pv.Plotter()
    p.add_mesh(grid, scalars=scal_name, cmap=cmap, scalar_bar_args=dict(title=bar_title))
    p.add_axes()
    p.add_text(title, font_size=12)
    p.show_grid()
    return p, grid


def main() -> None:
    """
    CLI to build a curtain slice from FEMTIC NPZ element arrays.

    Example
    -------
    python -m femtic_polyline_slice \\
        --npz elements_arrays.npz \\
        --polyline-csv path_points.csv \\
        --zmin -2500 --zmax 0 --nz 201 --ns 301 \\
        --power 2.0 \\
        --out-npz curtain_slice.npz \\
        --out-csv curtain_slice.csv \\
        --vtk curtain_slice.vts \\
        --screenshot curtain_slice.png
    """
    import argparse
    import csv

    ap = argparse.ArgumentParser(description="Curtain slice along XY polyline (IDW) from FEMTIC NPZ arrays.")
    ap.add_argument("--npz", required=True, help="Element NPZ with 'centroid' and 'log10_resistivity'.")
    ap.add_argument("--polyline-csv", help="CSV file with columns x,y listing polyline vertices.")
    ap.add_argument("--xy", action="append", nargs=2, type=float, metavar=("X", "Y"),
                    help="Polyline vertex (X,Y); repeat to build polyline.")
    ap.add_argument("--zmin", type=float, required=True)
    ap.add_argument("--zmax", type=float, required=True)
    ap.add_argument("--nz", type=int, default=201)
    ap.add_argument("--ns", type=int, default=301)
    ap.add_argument("--power", type=float, default=2.0)
    ap.add_argument("--out-npz", default=None)
    ap.add_argument("--out-csv", default=None)
    ap.add_argument("--vtk", default=None)
    ap.add_argument("--screenshot", default=None)
    ap.add_argument("--no-show", action="store_true")
    args = ap.parse_args()

    data = np.load(args.npz)
    if "centroid" not in data or "log10_resistivity" not in data:
        raise KeyError("NPZ must contain 'centroid' and 'log10_resistivity'.")

    centroids = data["centroid"]
    vals_log10 = data["log10_resistivity"]
    if "flag" in data:
        mask = data["flag"] != 1
        centroids = centroids[mask]
        vals_log10 = vals_log10[mask]

    # Polyline
    if args.polyline_csv:
        pts = []
        with open(args.polyline_csv, "r") as f:
            r = csv.reader(f)
            for row in r:
                if not row:
                    continue
                try:
                    x = float(row[0])
                    y = float(row[1])
                except Exception:
                    continue
                pts.append([x, y])
        points_xy = np.asarray(pts, dtype=float)
    else:
        if not args.xy or len(args.xy) < 2:
            raise ValueError("Provide >=2 vertices via --xy X Y or use --polyline-csv.")
        points_xy = np.asarray([[x, y] for x, y in args.xy], dtype=float)

    Z = np.linspace(args.zmin, args.zmax, args.nz)
    S, Z, V_log10, XY = curtain_slice_idw(points_xy, Z, centroids, vals_log10, power=args.power, ns=args.ns)

    if args.out_npz:
        np.savez_compressed(args.out_npz, S=S, Z=Z, V_log10=V_log10, XY=XY)
        print("Saved curtain NPZ:", args.out_npz)

    if args.out_csv:
        with open(args.out_csv, "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["s", "z", "log10_rho"])
            for j, s in enumerate(S):
                for i, z in enumerate(Z):
                    w.writerow([s, z, V_log10[i, j]])
        print("Saved curtain CSV:", args.out_csv)

    # PyVista visualisation (optional)
    try:
        V_lin = 10.0 ** V_log10
        p, grid = plot_curtain_pyvista(S, Z, V_lin, XY, logscale=True)
        if args.vtk:
            try:
                grid.save(args.vtk)
                print("Saved VTK:", args.vtk)
            except Exception as exc:
                print("Failed to save VTK:", exc)
        if args.screenshot:
            try:
                p.screenshot(args.screenshot)
                print("Saved screenshot:", args.screenshot)
            except Exception as exc:
                print("Failed to save screenshot:", exc)
        if not args.no_show:
            p.show()
    except ImportError as exc:
        print("PyVista not available; skipping interactive visualisation:", exc)


if __name__ == "__main__":
    main()
