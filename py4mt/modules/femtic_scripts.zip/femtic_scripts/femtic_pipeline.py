"""
femtic_pipeline.py

Simple FEMTIC pipeline: inject region-based values from an NPZ file into a
rho / resistivity-block file using femtic_rho_inject.

The NPZ file is expected to contain at least:

    region_rho          (nreg,)

and optionally:

    region_rho_lower    (nreg,)
    region_rho_upper    (nreg,)

Author: Volker Rath (DIAS)
Created by ChatGPT (GPT-5 Thinking) on 2025-12-07
"""
from __future__ import annotations

from typing import Optional
import numpy as np
from femtic_rho_inject import inject_region_values


def run_pipeline(
    npz_regions: str,
    template_rho: str,
    out_rho: str,
    *,
    write_space: str = "linear",
    n_override: Optional[int] = None,
    fmt: str = "{:.6g}",
) -> None:
    """
    Inject region-based values from NPZ into a FEMTIC rho file.

    Parameters
    ----------
    npz_regions : str
        NPZ file with region_rho and optional region_rho_lower/upper.
        region_rho is either in linear or log10 space depending on write_space.
    template_rho : str
        Input template rho / block file to be modified.
    out_rho : str
        Output rho / block file name.
    write_space : {'linear', 'log10'}, optional
        Interpretation of region_rho in NPZ. If 'log10', values are converted
        with 10** before injection (same for bounds if present).
    n_override : int, optional
        If given, override sharpness parameter n for all regions.
    fmt : str, optional
        Floating-point format string used when writing values.
    """
    data = np.load(npz_regions)
    if "region_rho" not in data:
        raise KeyError("NPZ must contain 'region_rho'.")

    vals = np.asarray(data["region_rho"], dtype=float)
    lower = data["region_rho_lower"] if "region_rho_lower" in data else None
    upper = data["region_rho_upper"] if "region_rho_upper" in data else None

    if write_space == "log10":
        vals = 10.0 ** vals
        if lower is not None:
            lower = 10.0 ** np.asarray(lower, dtype=float)
        if upper is not None:
            upper = 10.0 ** np.asarray(upper, dtype=float)

    inject_region_values(
        template_rho,
        out_rho,
        vals,
        lower=lower,
        upper=upper,
        n_override=n_override,
        fmt=fmt,
    )


def main() -> None:
    """
    CLI wrapper around run_pipeline.

    Example
    -------
    python -m femtic_pipeline \\
        --npz-regions region_values.npz \\
        --template-rho resistivity_block_iter0.dat \\
        --out-rho resistivity_block_iter0_updated.dat \\
        --write-space linear \\
        --n-override 2
    """
    import argparse

    ap = argparse.ArgumentParser(description="FEMTIC NPZ->rho injection pipeline.")
    ap.add_argument("--npz-regions", required=True, help="NPZ with region_rho (+optional bounds).")
    ap.add_argument("--template-rho", required=True, help="Template rho / block file.")
    ap.add_argument("--out-rho", required=True, help="Output rho / block file.")
    ap.add_argument("--write-space", choices=["linear", "log10"], default="linear")
    ap.add_argument("--n-override", type=int, choices=[1, 2, 3], default=None)
    ap.add_argument("--format", dest="fmt", default="{:.6g}")
    args = ap.parse_args()

    run_pipeline(
        args.npz_regions,
        args.template_rho,
        args.out_rho,
        write_space=args.write_space,
        n_override=args.n_override,
        fmt=args.fmt,
    )
    print("Wrote:", args.out_rho)


if __name__ == "__main__":
    main()
