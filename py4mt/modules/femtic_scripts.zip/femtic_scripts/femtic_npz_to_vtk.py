#!/usr/bin/env python3
"""
femtic_npz_to_vtk.py

Export a FEMTIC model stored in an NPZ file (from femtic_mesh_to_npz.py)
to a VTK unstructured grid (.vtu or legacy .vtk) with cell data.

Expected NPZ contents (minimum)
-------------------------------
nodes               (nn, 3)      node coordinates [x, y, z]
conn                (nelem, 4)   tetra connectivity (node indices, 0-based)

Recommended extras (if present, will be written as cell_data)
-------------------------------------------------------------
log10_resistivity   (nelem,)
rho_lower           (nelem,)
rho_upper           (nelem,)
flag                (nelem,)
n                   (nelem,)
region              (nelem,)     or region_of_elem

Author: Volker Rath (DIAS)
Created by ChatGPT (GPT-5 Thinking) on 2025-12-08
"""
from __future__ import annotations

import numpy as np


def npz_to_unstructured_grid(npz_path: str):
    """Build a PyVista UnstructuredGrid from a FEMTIC NPZ file.

    Parameters
    ----------
    npz_path : str
        Path to NPZ created by femtic_mesh_to_npz.py.

    Returns
    -------
    grid : pyvista.UnstructuredGrid
        Unstructured grid with cell_data holding resistivity parameters if
        present in the NPZ.
    """
    try:
        import pyvista as pv
    except Exception as exc:  # pragma: no cover
        raise ImportError("pyvista is required for VTK export.") from exc

    data = np.load(npz_path)

    if "nodes" not in data or "conn" not in data:
        raise KeyError("NPZ must at least contain 'nodes' and 'conn'.")

    nodes = np.asarray(data["nodes"], dtype=float)
    conn = np.asarray(data["conn"], dtype=int)

    nelem = conn.shape[0]
    if conn.shape[1] != 4:
        raise ValueError("Connectivity must have 4 nodes per element (tetra).")

    # VTK cell array: [npts, n1, n2, n3, n4, npts, ...]
    n_per_cell = 4
    cells = np.hstack(
        [np.full((nelem, 1), n_per_cell, dtype=np.int64), conn.astype(np.int64)]
    ).ravel()

    # Cell types: VTK_TETRA = 10
    try:
        import pyvista as pv
        celltypes = np.full(nelem, pv.CellType.TETRA, dtype=np.uint8)
    except Exception:  # very old pyvista
        celltypes = np.full(nelem, 10, dtype=np.uint8)

    grid = pv.UnstructuredGrid(cells, celltypes, nodes)

    # Attach available element-based arrays as cell_data
    preferred_keys = [
        "log10_resistivity",
        "rho_lower",
        "rho_upper",
        "flag",
        "n",
        "region",
        "region_of_elem",
    ]
    for key in preferred_keys:
        if key in data:
            arr = np.asarray(data[key])
            if arr.shape[0] == nelem:
                name = "region" if key == "region_of_elem" else key
                grid.cell_data[name] = arr

    return grid


def save_vtk_from_npz(
    npz_path: str,
    out_vtu: str,
    *,
    out_legacy: str | None = None,
    scalar_name: str = "log10_resistivity",
) -> None:
    """Export NPZ FEMTIC model to VTK unstructured grid file(s).

    Parameters
    ----------
    npz_path : str
        Input NPZ file.
    out_vtu : str
        Output VTU file (XML unstructured grid).
    out_legacy : str, optional
        Optional legacy .vtk output file.
    scalar_name : str, optional
        Name of scalar to use as default in PyVista plotting.
    """
    grid = npz_to_unstructured_grid(npz_path)
    grid.save(out_vtu)
    print("Wrote VTU:", out_vtu)

    if out_legacy is not None:
        grid.save(out_legacy)
        print("Wrote legacy VTK:", out_legacy)

    # Optional quick plotting
    if scalar_name in grid.cell_data:
        print(f"Scalar '{scalar_name}' available for plotting.")
    else:
        print(f"Scalar '{scalar_name}' not present in grid.cell_data.")


def main() -> None:
    """CLI for exporting FEMTIC NPZ to VTK/VTU."""
    import argparse

    ap = argparse.ArgumentParser(
        description="Export FEMTIC NPZ model to VTK unstructured grid (.vtu/.vtk)."
    )
    ap.add_argument("--npz", required=True, help="NPZ from femtic_mesh_to_npz.py.")
    ap.add_argument("--out-vtu", required=True, help="Output .vtu file.")
    ap.add_argument("--out-legacy", default=None, help="Optional legacy .vtk file.")
    ap.add_argument(
        "--plot",
        action="store_true",
        help="Show an interactive PyVista plot after writing.",
    )
    ap.add_argument(
        "--scalar",
        default="log10_resistivity",
        help="Cell scalar name for plotting (default 'log10_resistivity').",
    )
    args = ap.parse_args()

    import pyvista as pv

    grid = npz_to_unstructured_grid(args.npz)
    grid.save(args.out_vtu)
    print("Wrote VTU:", args.out_vtu)

    if args.out_legacy is not None:
        grid.save(args.out_legacy)
        print("Wrote legacy VTK:", args.out_legacy)

    if args.plot:
        scalars = args.scalar if args.scalar in grid.cell_data else None
        grid.plot(
            scalars=scalars,
            cmap="viridis",
            show_edges=True,
        )


if __name__ == "__main__":  # pragma: no cover
    main()
