"""
femtic_borehole_viz.py

Plotting utilities for vertical borehole resistivity profiles using pure
Matplotlib.

Author: Volker Rath (DIAS)
Created by ChatGPT (GPT-5 Thinking) on 2025-12-07
"""
from __future__ import annotations

from typing import Optional, Sequence, Tuple
import numpy as np
import matplotlib.pyplot as plt


def plot_vertical_profile(
    z: np.ndarray,
    values: np.ndarray,
    *,
    label: Optional[str] = None,
    ax: Optional[plt.Axes] = None,
    logx: bool = False,
    z_positive_down: bool = True,
) -> Tuple[plt.Figure, plt.Axes]:
    """
    Plot a single vertical profile values(z).

    Parameters
    ----------
    z : ndarray, shape (n,)
        Depth or elevation samples.
    values : ndarray, shape (n,)
        Corresponding profile values (e.g., resistivity).
    label : str, optional
        Curve label for the legend.
    ax : matplotlib.axes.Axes, optional
        Existing axis to plot into. If None, a new figure and axis are created.
    logx : bool, optional
        If True, use logarithmic scaling on the x-axis.
    z_positive_down : bool, optional
        If True, orient the axis such that depth increases downwards.

    Returns
    -------
    fig, ax : Figure, Axes
        The Matplotlib figure and axes containing the plot.
    """
    if ax is None:
        fig, ax = plt.subplots(figsize=(4.0, 6.0))
    else:
        fig = ax.figure

    ax.plot(values, z, label=label)
    ax.set_xlabel("Resistivity")
    ax.set_ylabel("Depth z")

    if logx:
        ax.set_xscale("log")

    if z_positive_down:
        if z.size >= 2 and z[1] < z[0]:
            ax.invert_yaxis()
    else:
        if z.size >= 2 and z[1] > z[0]:
            ax.invert_yaxis()

    if label is not None:
        ax.legend()

    ax.grid(True, which="both", alpha=0.3)
    fig.tight_layout()
    return fig, ax


def plot_vertical_profiles(
    z: np.ndarray,
    profiles: Sequence[np.ndarray],
    *,
    labels: Optional[Sequence[str]] = None,
    ax: Optional[plt.Axes] = None,
    logx: bool = False,
    z_positive_down: bool = True,
) -> Tuple[plt.Figure, plt.Axes]:
    """
    Plot multiple vertical profiles on a shared z-axis.

    Parameters
    ----------
    z : ndarray, shape (n,)
        Depth or elevation samples.
    profiles : sequence of ndarray
        Collection of profiles values(z) to plot.
    labels : sequence of str, optional
        Labels for each profile curve.
    ax : matplotlib.axes.Axes, optional
        Existing axis to plot into. If None, a new figure and axis are created.
    logx : bool, optional
        If True, use logarithmic scaling on the x-axis.
    z_positive_down : bool, optional
        If True, orient the axis such that depth increases downwards.

    Returns
    -------
    fig, ax : Figure, Axes
        The Matplotlib figure and axes containing the plot.
    """
    if ax is None:
        fig, ax = plt.subplots(figsize=(4.5, 6.5))
    else:
        fig = ax.figure

    for i, prof in enumerate(profiles):
        lab = labels[i] if (labels is not None and i < len(labels)) else None
        ax.plot(prof, z, label=lab)

    ax.set_xlabel("Resistivity")
    ax.set_ylabel("Depth z")

    if logx:
        ax.set_xscale("log")

    if z_positive_down:
        if z.size >= 2 and z[1] < z[0]:
            ax.invert_yaxis()
    else:
        if z.size >= 2 and z[1] > z[0]:
            ax.invert_yaxis()

    if labels is not None:
        ax.legend()

    ax.grid(True, which="both", alpha=0.3)
    fig.tight_layout()
    return fig, ax
