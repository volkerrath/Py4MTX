"""
femtic_npz_to_femtic.py

Reconstruct FEMTIC mesh.dat and resistivity_block_iterX.dat from an NPZ file
created by femtic_mesh_to_npz.py.

The NPZ is expected to contain:
    nodes, conn, nelem, nreg,
    region_of_elem,
    region_rho, region_rho_lower, region_rho_upper,
    region_n, region_flag

Author: Volker Rath (DIAS)
Created by ChatGPT (GPT-5 Thinking) on 2025-12-07
"""
from __future__ import annotations

import numpy as np


def write_femtic_mesh(
    out_path: str,
    nodes: np.ndarray,
    conn: np.ndarray,
) -> None:
    """
    Write a FEMTIC-style mesh.dat file from nodes and connectivity.

    Parameters
    ----------
    out_path : str
        Output file name for mesh.dat.
    nodes : ndarray, shape (nn, 3)
        Node coordinates [x, y, z].
    conn : ndarray, shape (nelem, 4)
        Element connectivity as node indices (0-based).
    """
    nodes = np.asarray(nodes, dtype=float)
    conn = np.asarray(conn, dtype=int)
    nn = nodes.shape[0]
    nelem = conn.shape[0]

    with open(out_path, "w") as f:
        f.write("TETRA\n")
        f.write(f"{nn:d}\n")
        for i in range(nn):
            x, y, z = nodes[i]
            f.write(f"{i:d} {x:.8e} {y:.8e} {z:.8e}\n")

        f.write(f"{nelem:d}\n")
        for ie in range(nelem):
            n1, n2, n3, n4 = conn[ie]
            # neighbour columns unknown -> set to -1 (ignored)
            f.write(f"{ie:d} -1 -1 -1 -1 {n1:d} {n2:d} {n3:d} {n4:d}\n")


def write_resistivity_block(
    out_path: str,
    nelem: int,
    nreg: int,
    region_of_elem: np.ndarray,
    region_rho: np.ndarray,
    region_rho_lower: np.ndarray,
    region_rho_upper: np.ndarray,
    region_n: np.ndarray,
    region_flag: np.ndarray,
    *,
    fmt: str = "{:.6g}",
) -> None:
    """
    Write a FEMTIC-style resistivity_block_iterX.dat from region arrays.

    Parameters
    ----------
    out_path : str
        Output file name.
    nelem : int
        Number of elements.
    nreg : int
        Number of regions.
    region_of_elem : ndarray, shape (nelem,)
        Region index for each element.
    region_rho, region_rho_lower, region_rho_upper : ndarray, shape (nreg,)
        Region-level resistivity and bounds [Ω·m].
    region_n : ndarray, shape (nreg,)
        Sharpness parameter per region.
    region_flag : ndarray, shape (nreg,)
        Fixed/free flag per region.
    fmt : str, optional
        Format string for floats, e.g. "{:.6g}".
    """
    region_of_elem = np.asarray(region_of_elem, dtype=int)
    region_rho = np.asarray(region_rho, dtype=float)
    region_rho_lower = np.asarray(region_rho_lower, dtype=float)
    region_rho_upper = np.asarray(region_rho_upper, dtype=float)
    region_n = np.asarray(region_n, dtype=float)
    region_flag = np.asarray(region_flag, dtype=int)

    if region_of_elem.shape[0] != nelem:
        raise ValueError("region_of_elem length does not match nelem.")
    if any(arr.shape[0] != nreg for arr in [region_rho, region_rho_lower,
                                            region_rho_upper, region_n, region_flag]):
        raise ValueError("Region arrays must all have length nreg.")

    with open(out_path, "w") as f:
        # Header
        f.write(f"{nelem:d} {nreg:d}\n")

        # Element → region mapping
        for ie in range(nelem):
            f.write(f"{ie:d} {int(region_of_elem[ie]):d}\n")

        # Region lines
        for ireg in range(nreg):
            rho = fmt.format(region_rho[ireg])
            rmin = fmt.format(region_rho_lower[ireg])
            rmax = fmt.format(region_rho_upper[ireg])
            nval = int(region_n[ireg])
            flag = int(region_flag[ireg])
            f.write(f"{ireg:d} {rho} {rmin} {rmax} {nval:d} {flag:d}\n")


def npz_to_femtic(
    npz_path: str,
    mesh_out: str,
    rho_block_out: str,
    *,
    fmt: str = "{:.6g}",
) -> None:
    """
    Reconstruct FEMTIC mesh.dat and resistivity_block from an NPZ file.

    Parameters
    ----------
    npz_path : str
        Path to NPZ created by femtic_mesh_to_npz.py.
    mesh_out : str
        Output path for mesh.dat.
    rho_block_out : str
        Output path for resistivity_block_iterX.dat.
    fmt : str, optional
        Float format for resistivity and bounds in block file.
    """
    data = np.load(npz_path)

    required = [
        "nodes",
        "conn",
        "nelem",
        "nreg",
        "region_of_elem",
        "region_rho",
        "region_rho_lower",
        "region_rho_upper",
        "region_n",
        "region_flag",
    ]
    missing = [k for k in required if k not in data]
    if missing:
        raise KeyError(f"NPZ is missing required arrays: {missing}")

    nodes = data["nodes"]
    conn = data["conn"]
    nelem = int(data["nelem"])
    nreg = int(data["nreg"])
    region_of_elem = data["region_of_elem"]
    region_rho = data["region_rho"]
    region_rho_lower = data["region_rho_lower"]
    region_rho_upper = data["region_rho_upper"]
    region_n = data["region_n"]
    region_flag = data["region_flag"]

    write_femtic_mesh(mesh_out, nodes, conn)
    write_resistivity_block(
        rho_block_out,
        nelem,
        nreg,
        region_of_elem,
        region_rho,
        region_rho_lower,
        region_rho_upper,
        region_n,
        region_flag,
        fmt=fmt,
    )


def main() -> None:
    """
    CLI entry point for reconstructing FEMTIC files from NPZ.

    Example
    -------
    python -m femtic_npz_to_femtic \\
        --npz femtic_model.npz \\
        --mesh-out mesh_reconstructed.dat \\
        --rho-block-out resistivity_block_iter0_reconstructed.dat
    """
    import argparse

    ap = argparse.ArgumentParser(
        description="Recreate FEMTIC mesh.dat and resistivity_block_iterX.dat from NPZ."
    )
    ap.add_argument("--npz", required=True, help="NPZ from femtic_mesh_to_npz.")
    ap.add_argument("--mesh-out", required=True, help="Output mesh.dat.")
    ap.add_argument("--rho-block-out", required=True, help="Output resistivity_block_iterX.dat.")
    ap.add_argument("--format", dest="fmt", default="{:.6g}",
                    help='Float format for resistivity and bounds (default "{:.6g}").')
    args = ap.parse_args()

    npz_to_femtic(args.npz, args.mesh_out, args.rho_block_out, fmt=args.fmt)
    print("Wrote mesh to:", args.mesh_out)
    print("Wrote resistivity block to:", args.rho_block_out)


if __name__ == "__main__":
    main()
