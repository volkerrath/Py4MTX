#!/usr/bin/env python3
"""
femtic_map_slice_matplotlib.py

Horizontal FEMTIC resistivity slices (maps) at fixed depth from NPZ, pure
Matplotlib, with pluggable interpolation (idw / nearest / rbf).

NPZ is expected to contain at least:
    centroid            (nelem, 3)
    log10_resistivity   (nelem,)
    flag                (nelem,)  [optional, 1 = fixed]

Author: Volker Rath (DIAS)
Created by ChatGPT (GPT-5 Thinking) on 2025-12-08
"""
from __future__ import annotations

from typing import Tuple
import numpy as np
import matplotlib.pyplot as plt


def _select_depth_window(
    centroids: np.ndarray,
    vals_log10: np.ndarray,
    z0: float,
    dz: float,
) -> Tuple[np.ndarray, np.ndarray]:
    """Select centroids and log10 values within a vertical window around z0."""
    centroids = np.asarray(centroids, dtype=float)
    vals_log10 = np.asarray(vals_log10, dtype=float)
    z = centroids[:, 2]
    half = dz / 2.0
    mask = (z >= z0 - half) & (z <= z0 + half)
    if not np.any(mask):
        raise ValueError("No centroids found in the depth window around z0.")
    pts_xy = centroids[mask, :2]
    vals_sel = vals_log10[mask]
    return pts_xy, vals_sel


def _idw_grid_2d(
    x: np.ndarray,
    y: np.ndarray,
    pts_xy: np.ndarray,
    vals_log10: np.ndarray,
    power: float = 2.0,
    eps: float = 1e-6,
) -> np.ndarray:
    """2D IDW on regular (x, y) grid (log10-space)."""
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    pts_xy = np.asarray(pts_xy, float)
    vals_log10 = np.asarray(vals_log10, float)
    nx = x.size
    ny = y.size
    V = np.empty((ny, nx), float)
    px = pts_xy[:, 0]
    py = pts_xy[:, 1]
    for j in range(ny):
        yj = y[j]
        dy2 = (py - yj) ** 2
        for i in range(nx):
            xi = x[i]
            d2 = (px - xi) ** 2 + dy2 + eps**2
            w = 1.0 / (d2 ** (power / 2.0))
            V[j, i] = float(np.sum(w * vals_log10) / np.sum(w))
    return V


def _nearest_grid_2d(
    x: np.ndarray,
    y: np.ndarray,
    pts_xy: np.ndarray,
    vals_log10: np.ndarray,
) -> np.ndarray:
    """2D nearest neighbour interpolation on regular grid."""
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    pts_xy = np.asarray(pts_xy, float)
    vals_log10 = np.asarray(vals_log10, float)
    nx = x.size
    ny = y.size
    V = np.empty((ny, nx), float)
    try:
        from scipy.spatial import cKDTree  # type: ignore[attr-defined]
        tree = cKDTree(pts_xy)
        XX, YY = np.meshgrid(x, y)
        Q = np.column_stack([XX.ravel(), YY.ravel()])
        _, idx = tree.query(Q)
        V[:] = vals_log10[idx].reshape(ny, nx)
    except Exception:
        px = pts_xy[:, 0]
        py = pts_xy[:, 1]
        for j in range(ny):
            yj = y[j]
            dy2 = (py - yj) ** 2
            for i in range(nx):
                xi = x[i]
                d2 = (px - xi) ** 2 + dy2
                k = int(np.argmin(d2))
                V[j, i] = vals_log10[k]
    return V


def _rbf_grid_2d(
    x: np.ndarray,
    y: np.ndarray,
    pts_xy: np.ndarray,
    vals_log10: np.ndarray,
) -> np.ndarray:
    """2D RBF interpolation on regular grid (SciPy)."""
    try:
        from scipy.interpolate import RBFInterpolator  # type: ignore[attr-defined]
    except Exception as exc:  # pragma: no cover
        raise ImportError(
            "RBF interpolation requires scipy.interpolate.RBFInterpolator."
        ) from exc
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    pts_xy = np.asarray(pts_xy, float)
    vals_log10 = np.asarray(vals_log10, float)
    rbf = RBFInterpolator(pts_xy, vals_log10, kernel="thin_plate_spline")
    XX, YY = np.meshgrid(x, y)
    Q = np.column_stack([XX.ravel(), YY.ravel()])
    V_flat = rbf(Q)
    return V_flat.reshape(y.size, x.size)


def _grid_2d(
    x: np.ndarray,
    y: np.ndarray,
    pts_xy: np.ndarray,
    vals_log10: np.ndarray,
    *,
    interp: str = "idw",
    power: float = 2.0,
) -> np.ndarray:
    """Dispatch 2D interpolation on a regular grid."""
    interp = interp.lower()
    if interp == "idw":
        return _idw_grid_2d(x, y, pts_xy, vals_log10, power=power)
    if interp == "nearest":
        return _nearest_grid_2d(x, y, pts_xy, vals_log10)
    if interp == "rbf":
        return _rbf_grid_2d(x, y, pts_xy, vals_log10)
    raise ValueError(f"Unknown interp '{interp}' (expected idw, nearest, rbf).")


def plot_map_slice_matplotlib(
    X: np.ndarray,
    Y: np.ndarray,
    V: np.ndarray,
    *,
    logscale: bool = True,
    cmap: str = "viridis",
    vmin: float | None = None,
    vmax: float | None = None,
    title: str = "Horizontal slice",
    z_label: str | None = None,
) -> tuple[plt.Figure, plt.Axes]:
    """Plot a horizontal map slice using Matplotlib."""
    X = np.asarray(X, float)
    Y = np.asarray(Y, float)
    V = np.asarray(V, float)
    if logscale:
        data = np.log10(np.clip(V, 1e-30, np.inf))
        cbar_label = "log10(ρ) [Ω·m]"
    else:
        data = V
        cbar_label = "ρ [Ω·m]"
    fig, ax = plt.subplots(figsize=(6.0, 5.0))
    pc = ax.pcolormesh(X, Y, data, shading="auto", cmap=cmap,
                       vmin=vmin, vmax=vmax)
    ax.set_aspect("equal")
    ax.set_xlabel("x")
    ax.set_ylabel("y")
    full_title = title
    if z_label is not None:
        full_title = f"{title} ({z_label})"
    ax.set_title(full_title)
    cbar = fig.colorbar(pc, ax=ax)
    cbar.set_label(cbar_label)
    fig.tight_layout()
    return fig, ax


def femtic_map_slice_from_npz_matplotlib(
    npz_path: str,
    *,
    z0: float,
    dz: float,
    nx: int = 200,
    ny: int = 200,
    xmin: float | None = None,
    xmax: float | None = None,
    ymin: float | None = None,
    ymax: float | None = None,
    power: float = 2.0,
    interp: str = "idw",
    logscale: bool = True,
    cmap: str = "viridis",
    vmin: float | None = None,
    vmax: float | None = None,
    out_npz: str | None = None,
    out_csv: str | None = None,
    out_png: str | None = None,
    title: str = "Horizontal slice",
) -> None:
    """High-level helper: compute horizontal map slice from FEMTIC NPZ and plot."""
    import csv

    data = np.load(npz_path)
    if "centroid" not in data or "log10_resistivity" not in data:
        raise KeyError("NPZ must contain 'centroid' and 'log10_resistivity'.")
    centroids = data["centroid"]
    vals_log10 = data["log10_resistivity"]
    if "flag" in data:
        mask = data["flag"] != 1
        centroids = centroids[mask]
        vals_log10 = vals_log10[mask]

    pts_xy, vals_sel = _select_depth_window(centroids, vals_log10, z0=z0, dz=dz)

    if xmin is None:
        xmin = float(pts_xy[:, 0].min())
    if xmax is None:
        xmax = float(pts_xy[:, 0].max())
    if ymin is None:
        ymin = float(pts_xy[:, 1].min())
    if ymax is None:
        ymax = float(pts_xy[:, 1].max())

    dx = xmax - xmin
    dy = ymax - ymin
    xmin -= 0.02 * dx
    xmax += 0.02 * dx
    ymin -= 0.02 * dy
    ymax += 0.02 * dy

    x = np.linspace(xmin, xmax, nx)
    y = np.linspace(ymin, ymax, ny)
    V_log10 = _grid_2d(x, y, pts_xy, vals_sel, interp=interp, power=power)
    X, Y = np.meshgrid(x, y)

    if out_npz is not None:
        np.savez_compressed(out_npz, X=X, Y=Y, V_log10=V_log10, z0=z0, interp=interp)
        print("Saved map slice NPZ:", out_npz)

    if out_csv is not None:
        with open(out_csv, "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["x", "y", "log10_rho", "z"])
            for j in range(ny):
                for i in range(nx):
                    w.writerow([X[j, i], Y[j, i], V_log10[j, i], z0])
        print("Saved map slice CSV:", out_csv)

    V_plot = 10.0 ** V_log10
    z_label = f"z = {z0:g} m"
    fig, ax = plot_map_slice_matplotlib(
        X,
        Y,
        V_plot,
        logscale=logscale,
        cmap=cmap,
        vmin=vmin,
        vmax=vmax,
        title=title,
        z_label=z_label,
    )

    if out_png is not None:
        fig.savefig(out_png, dpi=200, bbox_inches="tight")
        print("Saved PNG:", out_png)
    else:
        try:
            plt.show()
        except Exception:
            pass


def main() -> None:
    """CLI entry point for computing & plotting FEMTIC horizontal slices."""
    import argparse

    ap = argparse.ArgumentParser(
        description="Horizontal FEMTIC resistivity slices at fixed depth (Matplotlib)."
    )
    ap.add_argument("--npz", required=True, help="Element NPZ from femtic_mesh_to_npz.py.")
    ap.add_argument("--z0", type=float, required=True, help="Central depth of slice.")
    ap.add_argument("--dz", type=float, required=True, help="Thickness of vertical window around z0.")
    ap.add_argument("--nx", type=int, default=200, help="Number of grid points in x.")
    ap.add_argument("--ny", type=int, default=200, help="Number of grid points in y.")
    ap.add_argument("--xmin", type=float, default=None, help="Minimum x for grid.")
    ap.add_argument("--xmax", type=float, default=None, help="Maximum x for grid.")
    ap.add_argument("--ymin", type=float, default=None, help="Minimum y for grid.")
    ap.add_argument("--ymax", type=float, default=None, help="Maximum y for grid.")
    ap.add_argument("--power", type=float, default=2.0, help="IDW power exponent (interp='idw').")
    ap.add_argument(
        "--interp",
        choices=["idw", "nearest", "rbf"],
        default="idw",
        help="Interpolation method.",
    )
    ap.add_argument("--logscale", action="store_true", help="Plot in log10(ρ).")
    ap.add_argument("--cmap", default="viridis", help="Matplotlib colormap name.")
    ap.add_argument("--vmin", type=float, default=None, help="Color scale minimum.")
    ap.add_argument("--vmax", type=float, default=None, help="Color scale maximum.")
    ap.add_argument("--out-npz", default=None, help="Optional output NPZ for map slice.")
    ap.add_argument("--out-csv", default=None, help="Optional output CSV for map slice.")
    ap.add_argument("--out-png", default=None, help="Optional PNG output for the plot.")
    ap.add_argument("--title", default="Horizontal slice", help="Plot title.")
    args = ap.parse_args()

    femtic_map_slice_from_npz_matplotlib(
        npz_path=args.npz,
        z0=args.z0,
        dz=args.dz,
        nx=args.nx,
        ny=args.ny,
        xmin=args.xmin,
        xmax=args.xmax,
        ymin=args.ymin,
        ymax=args.ymax,
        power=args.power,
        interp=args.interp,
        logscale=args.logscale,
        cmap=args.cmap,
        vmin=args.vmin,
        vmax=args.vmax,
        out_npz=args.out_npz,
        out_csv=args.out_csv,
        out_png=args.out_png,
        title=args.title,
    )


if __name__ == "__main__":
    main()
