#!/usr/bin/env python3
"""
femtic_map_slice_matplotlib.py

Compute and plot horizontal resistivity slices (maps) at fixed depth z0 from
FEMTIC element NPZ files using pure Matplotlib.

The NPZ file is expected to come from femtic_mesh_to_npz.py and to contain
at least:

    centroid            (nelem, 3)
    log10_resistivity   (nelem,)
    flag                (nelem,)  [optional, 1 = fixed]

Fixed elements (flag == 1) are ignored when present.

A depth slice is defined by a central depth z0 and a vertical window +/- dz/2.
All elements with centroids in that depth window contribute to a 2D inverse
distance weighting (IDW) interpolation on a regular (x, y) grid, producing a
map that is then plotted with Matplotlib.

Author: Volker Rath (DIAS)
Created by ChatGPT (GPT-5 Thinking) on 2025-12-08
"""
from __future__ import annotations

from typing import Tuple
import numpy as np
import matplotlib.pyplot as plt


# ---------------------------------------------------------------------------
# 2D IDW interpolation helpers
# ---------------------------------------------------------------------------

def _select_depth_window(
    centroids: np.ndarray,
    vals_log10: np.ndarray,
    z0: float,
    dz: float,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Select centroids and log10 values within a vertical window around z0.

    Parameters
    ----------
    centroids : ndarray, shape (nelem, 3)
        Element centroids [x, y, z].
    vals_log10 : ndarray, shape (nelem,)
        Element log10(resistivity) values.
    z0 : float
        Central depth of the slice.
    dz : float
        Total thickness of the vertical window.

    Returns
    -------
    pts_xy : ndarray, shape (n_sel, 2)
        Selected XY positions of centroids.
    vals_sel : ndarray, shape (n_sel,)
        Selected log10(resistivity) values.
    """
    centroids = np.asarray(centroids, dtype=float)
    vals_log10 = np.asarray(vals_log10, dtype=float)

    z = centroids[:, 2]
    half = dz / 2.0
    mask = (z >= z0 - half) & (z <= z0 + half)
    if not np.any(mask):
        raise ValueError("No centroids found in the depth window around z0.")

    pts_xy = centroids[mask, :2]
    vals_sel = vals_log10[mask]

    return pts_xy, vals_sel


def _idw_grid_2d(
    x: np.ndarray,
    y: np.ndarray,
    pts_xy: np.ndarray,
    vals_log10: np.ndarray,
    power: float = 2.0,
    eps: float = 1e-6,
) -> np.ndarray:
    """
    Interpolate a 2D grid using inverse distance weighting in log10 space.

    Parameters
    ----------
    x, y : ndarray, shape (nx,), (ny,)
        Grid coordinates in x and y.
    pts_xy : ndarray, shape (n, 2)
        Data locations [x, y].
    vals_log10 : ndarray, shape (n,)
        Log10-space data values at pts_xy.
    power : float, optional
        IDW power exponent.
    eps : float, optional
        Small regularisation term added to squared distances.

    Returns
    -------
    V_log10 : ndarray, shape (ny, nx)
        Interpolated values in log10 space at grid points.
    """
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    pts_xy = np.asarray(pts_xy, dtype=float)
    vals_log10 = np.asarray(vals_log10, dtype=float)

    nx = x.size
    ny = y.size
    V = np.empty((ny, nx), dtype=float)

    px = pts_xy[:, 0]
    py = pts_xy[:, 1]

    for j in range(ny):
        yj = y[j]
        dy2 = (py - yj) ** 2
        for i in range(nx):
            xi = x[i]
            d2 = (px - xi) ** 2 + dy2 + eps**2
            w = 1.0 / (d2 ** (power / 2.0))
            V[j, i] = float(np.sum(w * vals_log10) / np.sum(w))

    return V


# ---------------------------------------------------------------------------
# Matplotlib plotting
# ---------------------------------------------------------------------------

def plot_map_slice_matplotlib(
    X: np.ndarray,
    Y: np.ndarray,
    V: np.ndarray,
    *,
    logscale: bool = True,
    cmap: str = "viridis",
    vmin: float | None = None,
    vmax: float | None = None,
    title: str = "Horizontal slice",
    z_label: str | None = None,
) -> tuple[plt.Figure, plt.Axes]:
    """
    Plot a horizontal map slice using Matplotlib.

    Parameters
    ----------
    X, Y : ndarray, shape (ny, nx)
        Meshgrid of coordinates. X varies in x-direction, Y in y-direction.
    V : ndarray, shape (ny, nx)
        Values for the slice. If logscale is True, V is interpreted as
        linear resistivity [Ω·m] and plotted as log10(V).
    logscale : bool, optional
        If True, color scale is in log10(ρ). If False, in linear ρ.
    cmap : str, optional
        Colormap name.
    vmin, vmax : float, optional
        Color limits. If None, determined automatically.
    title : str, optional
        Figure title.
    z_label : str, optional
        Extra label indicating depth (e.g. "z = -1000 m") appended to the title.

    Returns
    -------
    fig, ax : Figure, Axes
        Matplotlib figure and axes.
    """
    X = np.asarray(X, dtype=float)
    Y = np.asarray(Y, dtype=float)
    V = np.asarray(V, dtype=float)

    if logscale:
        data = np.log10(np.clip(V, 1e-30, np.inf))
        cbar_label = "log10(ρ) [Ω·m]"
    else:
        data = V
        cbar_label = "ρ [Ω·m]"

    fig, ax = plt.subplots(figsize=(6.0, 5.0))

    # pcolormesh expects 2D X, Y and C with same shape (or one larger in x/y)
    pc = ax.pcolormesh(X, Y, data, shading="auto", cmap=cmap, vmin=vmin, vmax=vmax)

    ax.set_aspect("equal")
    ax.set_xlabel("x")
    ax.set_ylabel("y")

    full_title = title
    if z_label is not None:
        full_title = f"{title} ({z_label})"
    ax.set_title(full_title)

    cbar = fig.colorbar(pc, ax=ax)
    cbar.set_label(cbar_label)

    fig.tight_layout()
    return fig, ax


# ---------------------------------------------------------------------------
# High-level wrapper & CLI
# ---------------------------------------------------------------------------

def femtic_map_slice_from_npz_matplotlib(
    npz_path: str,
    *,
    z0: float,
    dz: float,
    nx: int = 200,
    ny: int = 200,
    xmin: float | None = None,
    xmax: float | None = None,
    ymin: float | None = None,
    ymax: float | None = None,
    power: float = 2.0,
    logscale: bool = True,
    cmap: str = "viridis",
    vmin: float | None = None,
    vmax: float | None = None,
    out_npz: str | None = None,
    out_csv: str | None = None,
    out_png: str | None = None,
    title: str = "Horizontal slice",
) -> None:
    """
    High-level helper: compute horizontal map slice from FEMTIC NPZ and plot.

    Parameters
    ----------
    npz_path : str
        NPZ file with 'centroid', 'log10_resistivity', and optional 'flag'.
    z0 : float
        Central depth of the slice.
    dz : float
        Total thickness of vertical window around z0.
    nx, ny : int, optional
        Number of grid points in x and y for the map.
    xmin, xmax, ymin, ymax : float, optional
        Spatial bounds for the grid. If any of them is None, the bounds are
        inferred from the centroids of the selected elements, with a small
        margin.
    power : float, optional
        IDW power exponent.
    logscale : bool, optional
        If True, color bar in log10(ρ). If False, in linear ρ.
    cmap : str, optional
        Matplotlib colormap name.
    vmin, vmax : float, optional
        Color limits.
    out_npz : str, optional
        If given, save slice arrays (X, Y, V_log10, z0) to NPZ (grid-based).
    out_csv : str, optional
        If given, save slice data (x, y, log10_rho, z0) to CSV (flattened).
    out_png : str, optional
        If given, save Matplotlib figure to PNG.
    title : str, optional
        Plot title.
    """
    import csv

    data = np.load(npz_path)
    if "centroid" not in data or "log10_resistivity" not in data:
        raise KeyError("NPZ must contain 'centroid' and 'log10_resistivity'.")

    centroids = data["centroid"]
    vals_log10 = data["log10_resistivity"]

    # Drop fixed elements if flag is present
    if "flag" in data:
        mask = data["flag"] != 1
        centroids = centroids[mask]
        vals_log10 = vals_log10[mask]

    # Select depth window
    pts_xy, vals_sel = _select_depth_window(centroids, vals_log10, z0=z0, dz=dz)

    # Determine grid extents if not provided
    if xmin is None:
        xmin = float(pts_xy[:, 0].min())
    if xmax is None:
        xmax = float(pts_xy[:, 0].max())
    if ymin is None:
        ymin = float(pts_xy[:, 1].min())
    if ymax is None:
        ymax = float(pts_xy[:, 1].max())

    # Add a small margin
    dx = xmax - xmin
    dy = ymax - ymin
    xmin -= 0.02 * dx
    xmax += 0.02 * dx
    ymin -= 0.02 * dy
    ymax += 0.02 * dy

    x = np.linspace(xmin, xmax, nx)
    y = np.linspace(ymin, ymax, ny)
    V_log10 = _idw_grid_2d(x, y, pts_xy, vals_sel, power=power)

    X, Y = np.meshgrid(x, y)

    # Save slice (grid-based) if requested
    if out_npz is not None:
        np.savez_compressed(out_npz, X=X, Y=Y, V_log10=V_log10, z0=z0)
        print("Saved map slice NPZ:", out_npz)

    # Save CSV (flattened) if requested
    if out_csv is not None:
        with open(out_csv, "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["x", "y", "log10_rho", "z"])
            for j in range(ny):
                for i in range(nx):
                    w.writerow([X[j, i], Y[j, i], V_log10[j, i], z0])
        print("Saved map slice CSV:", out_csv)

    # For plotting, convert to linear or keep log-based according to logscale
    if logscale:
        V_plot = 10.0 ** V_log10  # colorbar is log10(ρ)
    else:
        V_plot = 10.0 ** V_log10  # still linear; colorbar is linear ρ

    z_label = f"z = {z0:g} m"
    fig, ax = plot_map_slice_matplotlib(
        X,
        Y,
        V_plot,
        logscale=logscale,
        cmap=cmap,
        vmin=vmin,
        vmax=vmax,
        title=title,
        z_label=z_label,
    )

    if out_png is not None:
        fig.savefig(out_png, dpi=200, bbox_inches="tight")
        print("Saved PNG:", out_png)
    else:
        try:
            plt.show()
        except Exception:
            pass


def main() -> None:
    """
    CLI entry point for computing & plotting FEMTIC horizontal slices.

    Examples
    --------
    1) Simple horizontal slice at z0 = -1000 m, window dz = 200 m:

        python -m femtic_map_slice_matplotlib \\
            --npz femtic_model.npz \\
            --z0 -1000 --dz 200 \\
            --nx 200 --ny 200 \\
            --logscale \\
            --out-png slice_z-1000.png

    2) Same but explicitly define bounds and export NPZ + CSV:

        python -m femtic_map_slice_matplotlib \\
            --npz femtic_model.npz \\
            --z0 -1500 --dz 300 \\
            --nx 300 --ny 300 \\
            --xmin 0 --xmax 5000 --ymin 0 --ymax 4000 \\
            --logscale \\
            --out-npz slice_z-1500.npz \\
            --out-csv slice_z-1500.csv \\
            --out-png slice_z-1500.png
    """
    import argparse

    ap = argparse.ArgumentParser(
        description="Horizontal FEMTIC resistivity slices at fixed depth (Matplotlib)."
    )
    ap.add_argument("--npz", required=True, help="Element NPZ from femtic_mesh_to_npz.py.")
    ap.add_argument("--z0", type=float, required=True, help="Central depth of slice.")
    ap.add_argument("--dz", type=float, required=True, help="Thickness of vertical window around z0.")
    ap.add_argument("--nx", type=int, default=200, help="Number of grid points in x.")
    ap.add_argument("--ny", type=int, default=200, help="Number of grid points in y.")
    ap.add_argument("--xmin", type=float, default=None, help="Minimum x for grid.")
    ap.add_argument("--xmax", type=float, default=None, help="Maximum x for grid.")
    ap.add_argument("--ymin", type=float, default=None, help="Minimum y for grid.")
    ap.add_argument("--ymax", type=float, default=None, help="Maximum y for grid.")
    ap.add_argument("--power", type=float, default=2.0, help="IDW power exponent.")
    ap.add_argument("--logscale", action="store_true", help="Plot in log10(ρ).")
    ap.add_argument("--cmap", default="viridis", help="Matplotlib colormap name.")
    ap.add_argument("--vmin", type=float, default=None, help="Color scale minimum.")
    ap.add_argument("--vmax", type=float, default=None, help="Color scale maximum.")
    ap.add_argument("--out-npz", default=None, help="Optional output NPZ for map slice.")
    ap.add_argument("--out-csv", default=None, help="Optional output CSV for map slice.")
    ap.add_argument("--out-png", default=None, help="Optional PNG output for the plot.")
    ap.add_argument("--title", default="Horizontal slice", help="Plot title.")
    args = ap.parse_args()

    femtic_map_slice_from_npz_matplotlib(
        npz_path=args.npz,
        z0=args.z0,
        dz=args.dz,
        nx=args.nx,
        ny=args.ny,
        xmin=args.xmin,
        xmax=args.xmax,
        ymin=args.ymin,
        ymax=args.ymax,
        power=args.power,
        logscale=args.logscale,
        cmap=args.cmap,
        vmin=args.vmin,
        vmax=args.vmax,
        out_npz=args.out_npz,
        out_csv=args.out_csv,
        out_png=args.out_png,
        title=args.title,
    )


if __name__ == "__main__":
    main()
