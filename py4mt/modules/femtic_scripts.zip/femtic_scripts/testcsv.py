#!/usr/bin/env python3

import numpy as np

with open('transect_x.csv') as single:
    lines=single.readlines()
    for line in lines:
        myarray = np.fromstring(line, dtype=float, sep=',')
        print(myarray)
