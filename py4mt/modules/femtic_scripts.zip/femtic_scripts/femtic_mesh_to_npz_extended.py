"""
femtic_mesh_to_npz.py

Build per-element arrays from FEMTIC mesh.dat and resistivity_block_iterX.dat
and save them together with the mesh itself (nodes, connectivity) and the
region-level information into a compressed NPZ file.

Input formats
-------------

mesh.dat  (FEMTIC TETRA mesh)
    Line 1 : TETRA
    Line 2 : nn               (number of nodes)
    Next nn lines:
        i  x  y  z            (node index, 0-based, and coordinates)
    Next line:
        nelem                 (number of tetrahedra)
    Next nelem lines:
        ie  nnb1 nnb2 nnb3 nnb4  n1 n2 n3 n4
        - ie      : element index (0-based)
        - nnb1-4  : neighbour / auxiliary indices (ignored here)
        - n1-4    : node indices (0-based) defining the tetrahedron

resistivity_block_iterX.dat
    Line 1 : nelem  nreg
    Next nelem lines:
        ie  ireg
    Next nreg lines:
        ireg  rho  rho_min  rho_max  n  flag
        - rho      : region resistivity [Ω·m]
        - rho_min  : lower bound [Ω·m]
        - rho_max  : upper bound [Ω·m]
        - n        : sharpness parameter (1, 2, or 3)
        - flag     : 0 = free, 1 = fixed

Output NPZ contents
-------------------
nodes               (nn, 3)      node coordinates [x, y, z]
conn                (nelem, 4)   tetra connectivity (node indices)
nelem               ()           number of elements
nreg                ()           number of regions
region_of_elem      (nelem,)     region index of each element

region_rho          (nreg,)      region resistivity [Ω·m]
region_rho_lower    (nreg,)      region lower bound [Ω·m]
region_rho_upper    (nreg,)      region upper bound [Ω·m]
region_n            (nreg,)      sharpness parameter
region_flag         (nreg,)      fixed/free flag per region

centroid            (nelem, 3)   element centroids [x, y, z]
region              (nelem,)     region index of each element (same as region_of_elem)
log10_resistivity   (nelem,)     log10(rho) with clipping at >= 1e-30
rho_lower           (nelem,)     log10(rho_min)
rho_upper           (nelem,)     log10(rho_max)
flag                (nelem,)     fixed flag per element (0 or 1)
n                   (nelem,)     sharpness parameter per element

Author: Volker Rath (DIAS)
Created by ChatGPT (GPT-5 Thinking) on 2025-12-07
"""
from __future__ import annotations

from typing import Dict, Tuple
import numpy as np


def read_femtic_mesh(mesh_path: str) -> Tuple[np.ndarray, np.ndarray]:
    """
    Read a FEMTIC TETRA mesh file and return node coordinates and connectivity.

    Parameters
    ----------
    mesh_path : str
        Path to the mesh file (usually "mesh.dat").

    Returns
    -------
    nodes : ndarray, shape (nn, 3)
        Node coordinates [x, y, z].
    conn : ndarray, shape (nelem, 4)
        Tetrahedral connectivity as node indices (0-based) per element.
    """
    with open(mesh_path, "r", errors="ignore") as f:
        header = f.readline().strip()
        if header.upper() != "TETRA":
            raise ValueError(f"Unsupported mesh type '{header}', expected 'TETRA'.")

        nn_line = f.readline().split()
        if not nn_line:
            raise ValueError("Missing node count after 'TETRA' header.")
        nn = int(nn_line[0])

        nodes = np.empty((nn, 3), dtype=float)
        for _ in range(nn):
            line = f.readline()
            if not line:
                raise ValueError("Unexpected EOF while reading node coordinates.")
            parts = line.split()
            if len(parts) < 4:
                raise ValueError(f"Node line has too few columns: {line!r}")
            idx = int(parts[0])
            x, y, z = map(float, parts[1:4])
            if not (0 <= idx < nn):
                raise ValueError(f"Node index {idx} out of range 0..{nn-1}.")
            nodes[idx] = (x, y, z)

        nelem_line = f.readline().split()
        if not nelem_line:
            raise ValueError("Missing element count line after node block.")
        nelem = int(nelem_line[0])

        conn = np.empty((nelem, 4), dtype=int)
        for _ in range(nelem):
            line = f.readline()
            if not line:
                raise ValueError("Unexpected EOF while reading element block.")
            parts = line.split()
            if len(parts) < 9:
                raise ValueError(f"Element line has too few columns: {line!r}")
            ie = int(parts[0])
            n1, n2, n3, n4 = map(int, parts[-4:])
            if not (0 <= ie < nelem):
                raise ValueError(f"Element index {ie} out of range 0..{nelem-1}.")
            conn[ie] = (n1, n2, n3, n4)

    return nodes, conn


def read_resistivity_block(block_path: str) -> Dict[str, np.ndarray]:
    """
    Read a FEMTIC resistivity block file and return region-based data.

    Parameters
    ----------
    block_path : str
        Path to the resistivity_block_iterX.dat file.

    Returns
    -------
    data : dict
        Dictionary with keys:
            "nelem", "nreg"
            "region_of_elem"      (nelem,)
            "region_rho"          (nreg,)
            "region_rho_lower"    (nreg,)
            "region_rho_upper"    (nreg,)
            "region_n"            (nreg,)
            "region_flag"         (nreg,)
    """
    with open(block_path, "r", errors="ignore") as f:
        first = f.readline().split()
        if len(first) < 2:
            raise ValueError("First line must contain 'nelem nreg'.")
        nelem = int(first[0])
        nreg = int(first[1])

        region_of_elem = np.empty(nelem, dtype=int)
        for _ in range(nelem):
            line = f.readline()
            if not line:
                raise ValueError("Unexpected EOF while reading element-region map.")
            parts = line.split()
            if len(parts) < 2:
                raise ValueError(f"Element-region line has too few columns: {line!r}")
            ie = int(parts[0])
            ireg = int(parts[1])
            if not (0 <= ie < nelem):
                raise ValueError(f"Element index {ie} out of range 0..{nelem-1}.")
            region_of_elem[ie] = ireg

        region_rho = np.empty(nreg, dtype=float)
        region_rho_lower = np.empty(nreg, dtype=float)
        region_rho_upper = np.empty(nreg, dtype=float)
        region_n = np.empty(nreg, dtype=float)
        region_flag = np.empty(nreg, dtype=int)

        for _ in range(nreg):
            line = f.readline()
            if not line:
                raise ValueError("Unexpected EOF while reading region lines.")
            parts = line.split()
            if len(parts) < 6:
                raise ValueError(f"Region line has too few columns: {line!r}")
            ireg = int(parts[0])
            rho = float(parts[1])
            rho_min = float(parts[2])
            rho_max = float(parts[3])
            n = float(parts[4])
            flag = int(parts[5])
            if not (0 <= ireg < nreg):
                raise ValueError(f"Region index {ireg} out of range 0..{nreg-1}.")
            region_rho[ireg] = rho
            region_rho_lower[ireg] = rho_min
            region_rho_upper[ireg] = rho_max
            region_n[ireg] = n
            region_flag[ireg] = flag

    return {
        "nelem": np.array(nelem, dtype=int),
        "nreg": np.array(nreg, dtype=int),
        "region_of_elem": region_of_elem,
        "region_rho": region_rho,
        "region_rho_lower": region_rho_lower,
        "region_rho_upper": region_rho_upper,
        "region_n": region_n,
        "region_flag": region_flag,
    }


def build_element_arrays(
    nodes: np.ndarray,
    conn: np.ndarray,
    region_of_elem: np.ndarray,
    region_rho: np.ndarray,
    region_rho_lower: np.ndarray,
    region_rho_upper: np.ndarray,
    region_n: np.ndarray,
    region_flag: np.ndarray,
    *,
    clip_eps: float = 1e-30,
) -> Dict[str, np.ndarray]:
    """
    Build element-based arrays (centroids, log10 resistivity, bounds, flag, n).

    Parameters
    ----------
    nodes : ndarray, shape (nn, 3)
        Node coordinates.
    conn : ndarray, shape (nelem, 4)
        Tetrahedral connectivity.
    region_of_elem : ndarray, shape (nelem,)
        Region index of each element.
    region_rho, region_rho_lower, region_rho_upper : ndarray, shape (nreg,)
        Region-level resistivity and bounds [Ω·m].
    region_n : ndarray, shape (nreg,)
        Sharpness parameter per region.
    region_flag : ndarray, shape (nreg,)
        Fixed/free flag per region.
    clip_eps : float, optional
        Minimum rho before taking log10, default 1e-30.

    Returns
    -------
    arrays : dict
        Element-based arrays as described in the module docstring.
    """
    nodes = np.asarray(nodes, dtype=float)
    conn = np.asarray(conn, dtype=int)
    region_of_elem = np.asarray(region_of_elem, dtype=int)

    nelem = conn.shape[0]
    if region_of_elem.shape[0] != nelem:
        raise ValueError("region_of_elem length does not match number of elements.")

    coords = nodes[conn]  # (nelem, 4, 3)
    centroid = coords.mean(axis=1)

    rho = np.clip(region_rho, clip_eps, np.inf)
    rho_min = np.clip(region_rho_lower, clip_eps, np.inf)
    rho_max = np.clip(region_rho_upper, clip_eps, np.inf)

    rid = region_of_elem
    rho_elem = rho[rid]
    rho_min_elem = rho_min[rid]
    rho_max_elem = rho_max[rid]
    n_elem = region_n[rid]
    flag_elem = region_flag[rid]

    log10_rho = np.log10(rho_elem)
    log10_rho_min = np.log10(rho_min_elem)
    log10_rho_max = np.log10(rho_max_elem)

    return {
        "centroid": centroid,
        "region": rid,
        "log10_resistivity": log10_rho,
        "rho_lower": log10_rho_min,
        "rho_upper": log10_rho_max,
        "flag": flag_elem,
        "n": n_elem,
    }


def save_element_npz_with_mesh_and_regions(
    out_path: str,
    nodes: np.ndarray,
    conn: np.ndarray,
    block: Dict[str, np.ndarray],
    arrays: Dict[str, np.ndarray],
) -> None:
    """
    Save mesh, region data and element arrays to a compressed NPZ file.

    Parameters
    ----------
    out_path : str
        Output .npz file name.
    nodes : ndarray, shape (nn, 3)
        Node coordinates.
    conn : ndarray, shape (nelem, 4)
        Element connectivity.
    block : dict
        Region-level data as returned by read_resistivity_block.
    arrays : dict
        Element arrays produced by build_element_arrays.
    """
    np.savez_compressed(
        out_path,
        nodes=nodes,
        conn=conn,
        nelem=block["nelem"],
        nreg=block["nreg"],
        region_of_elem=block["region_of_elem"],
        region_rho=block["region_rho"],
        region_rho_lower=block["region_rho_lower"],
        region_rho_upper=block["region_rho_upper"],
        region_n=block["region_n"],
        region_flag=block["region_flag"],
        **arrays,
    )


def main() -> None:
    """
    Command-line interface to build mesh + region + element NPZ from FEMTIC files.

    Example
    -------
    python -m femtic_mesh_to_npz \\
        --mesh mesh.dat \\
        --rho-block resistivity_block_iter0.dat \\
        --out-npz femtic_model.npz
    """
    import argparse

    ap = argparse.ArgumentParser(
        description=(
            "Build FEMTIC mesh + region + element arrays (centroid, log10 rho, "
            "bounds, flag, n) from mesh.dat and resistivity_block_iterX.dat "
            "and store everything into a single NPZ file."
        )
    )
    ap.add_argument("--mesh", required=True, help="Path to FEMTIC mesh.dat.")
    ap.add_argument("--rho-block", required=True, help="Path to resistivity_block_iterX.dat.")
    ap.add_argument("--out-npz", required=True, help="Output NPZ file.")
    args = ap.parse_args()

    nodes, conn = read_femtic_mesh(args.mesh)
    block = read_resistivity_block(args.rho_block)

    arrays = build_element_arrays(
        nodes=nodes,
        conn=conn,
        region_of_elem=block["region_of_elem"],
        region_rho=block["region_rho"],
        region_rho_lower=block["region_rho_lower"],
        region_rho_upper=block["region_rho_upper"],
        region_n=block["region_n"],
        region_flag=block["region_flag"],
    )
    save_element_npz_with_mesh_and_regions(args.out_npz, nodes, conn, block, arrays)
    print("Saved mesh + region + element NPZ:", args.out_npz)


if __name__ == "__main__":
    main()
