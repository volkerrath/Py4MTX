"""
femtic_rho_inject.py

Inject region-based resistivity values (and optional bounds, n) into a
FEMTIC rho / resistivity-block file.

Only lines that look like region lines of the form

    ireg  rho  rho_min  rho_max  n  flag

are modified. All other lines are passed through unchanged.

Author: Volker Rath (DIAS)
Created by ChatGPT (GPT-5 Thinking) on 2025-12-07
"""
from __future__ import annotations

from typing import Optional, List
import numpy as np


def _try_parse_region_line(parts: List[str]):
    """
    Try to parse a region line.femtic_borehole_viz.py


    Expected format
    ---------------
    ireg  rho  rho_min  rho_max  n  flag

    Returns
    -------
    tuple or None
        (ireg, rho, rho_min, rho_max, n, flag) if parsing succeeds,
        otherwise None.
    """
    if len(parts) < 6:
        return None
    try:
        ireg = int(parts[0])
        rho = float(parts[1])
        rho_min = float(parts[2])
        rho_max = float(parts[3])
        n = float(parts[4])
        flag = int(parts[5])
    except Exception:
        return None
    return ireg, rho, rho_min, rho_max, n, flag


def inject_region_values(
    rho_template: str,
    out_path: str,
    values: np.ndarray,
    *,
    lower: Optional[np.ndarray] = None,
    upper: Optional[np.ndarray] = None,
    n_override: Optional[int] = None,
    fmt: str = "{:.6g}",
) -> None:
    """
    Inject region-based resistivity values into a FEMTIC rho / block file.

    Parameters
    ----------
    rho_template : str
        Input rho / resistivity-block file used as a template.
    out_path : str
        Output file name for the modified version.
    values : ndarray, shape (nreg,)
        New region resistivities in linear space [Ω·m].
    lower : ndarray, optional
        New lower bounds (linear space). If None, keep existing values.
    upper : ndarray, optional
        New upper bounds (linear space). If None, keep existing values.
    n_override : int, optional
        If given, new sharpness n for all regions (1, 2, or 3).
        If None, keep n values from the template.
    fmt : str, optional
        Floating-point format string for writing values, e.g. "{:.6g}".
    """
    values = np.asarray(values, dtype=float)
    lo = np.asarray(lower, dtype=float) if lower is not None else None
    hi = np.asarray(upper, dtype=float) if upper is not None else None

    with open(rho_template, "r", errors="ignore") as f:
        lines = f.readlines()

    out_lines: List[str] = []

    for ln in lines:
        parts = ln.split()
        parsed = _try_parse_region_line(parts)
        if parsed is None:
            out_lines.append(ln)
            continue

        ireg, rho_old, rho_min_old, rho_max_old, n_old, flag = parsed
        if not (0 <= ireg < values.size):
            out_lines.append(ln)
            continue

        rho_new = values[ireg]
        rho_min_new = lo[ireg] if lo is not None else rho_min_old
        rho_max_new = hi[ireg] if hi is not None else rho_max_old
        n_new = n_override if n_override is not None else n_old

        core = "{:d} ".format(ireg) + " ".join(
            [
                fmt.format(rho_new),
                fmt.format(rho_min_new),
                fmt.format(rho_max_new),
                str(int(n_new)),
                str(int(flag)),
            ]
        )
        out_lines.append(core + "\n")

    with open(out_path, "w") as f:
        f.writelines(out_lines)


def main() -> None:
    """
    Command-line wrapper to inject values from NPY or NPZ into a rho file.

    Usage examples
    --------------

    1) From NPY (region_rho in linear space):

        python -m femtic_rho_inject \\
            --template resistivity_block_iter0.dat \\
            --out resistivity_block_iter0_updated.dat \\
            --from-npy region_rho.npy

    2) From NPZ with region_rho, region_rho_lower, region_rho_upper:

        python -m femtic_rho_inject \\
            --template resistivity_block_iter0.dat \\
            --out resistivity_block_iter0_updated.dat \\
            --from-npz region_values.npz \\
            --n-override 2
    """
    import argparse

    ap = argparse.ArgumentParser(
        description="Inject region-based resistivities into FEMTIC rho / block file."
    )
    ap.add_argument("--template", required=True, help="Template rho / block file.")
    ap.add_argument("--out", required=True, help="Output rho / block file.")
    src = ap.add_mutually_exclusive_group(required=True)
    src.add_argument("--from-npy", help="NPY array of region resistivities (linear).")
    src.add_argument("--from-npz", help="NPZ with 'region_rho' and optional bounds.")
    ap.add_argument("--n-override", type=int, choices=[1, 2, 3], default=None)
    ap.add_argument("--format", dest="fmt", default="{:.6g}")
    args = ap.parse_args()

    if args.from_npy:
        vals = np.load(args.from_npy)
        lower = upper = None
    else:
        data = np.load(args.from_npz)
        if "region_rho" not in data:
            raise KeyError("NPZ must contain 'region_rho' for --from-npz mode.")
        vals = data["region_rho"]
        lower = data["region_rho_lower"] if "region_rho_lower" in data else None
        upper = data["region_rho_upper"] if "region_rho_upper" in data else None

    inject_region_values(
        args.template,
        args.out,
        vals,
        lower=lower,
        upper=upper,
        n_override=args.n_override,
        fmt=args.fmt,
    )
    print("Wrote:", args.out)


if __name__ == "__main__":
    main()
