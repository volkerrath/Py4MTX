"""
femtic_profiles.py

Compute vertical resistivity profiles from FEMTIC element arrays stored in an
NPZ file, and plot them using femtic_borehole_viz (pure Matplotlib).

Author: Volker Rath (DIAS)
Created by ChatGPT (GPT-5 Thinking) on 2025-12-07
"""
from __future__ import annotations

from typing import Literal, Tuple, List
import numpy as np
import matplotlib.pyplot as plt
from femtic_borehole_viz import plot_vertical_profiles


def _idw_profile(
    x0: float,
    y0: float,
    z_samples: np.ndarray,
    centroids: np.ndarray,
    vals_log10: np.ndarray,
    power: float = 2.0,
    eps: float = 1e-6,
) -> np.ndarray:
    """
    Compute a vertical profile at (x0, y0) using inverse-distance weighting.

    Parameters
    ----------
    x0, y0 : float
        Horizontal coordinates of the borehole.
    z_samples : ndarray, shape (nz,)
        Depth samples for the output profile.
    centroids : ndarray, shape (nelem, 3)
        Element centroids.
    vals_log10 : ndarray, shape (nelem,)
        Log10(resistivity) values at element centroids.
    power : float, optional
        IDW power exponent.
    eps : float, optional
        Small regularisation term added to squared distance.

    Returns
    -------
    prof_log10 : ndarray, shape (nz,)
        Interpolated profile in log10 space.
    """
    centroids = np.asarray(centroids, dtype=float)
    vals_log10 = np.asarray(vals_log10, dtype=float)
    cx, cy, cz = centroids[:, 0], centroids[:, 1], centroids[:, 2]
    out = np.empty_like(z_samples, dtype=float)

    for i, z in enumerate(z_samples):
        d2 = (cx - x0) ** 2 + (cy - y0) ** 2 + (cz - z) ** 2 + eps**2
        w = 1.0 / (d2 ** (power / 2.0))
        out[i] = np.sum(w * vals_log10) / np.sum(w)

    return out


def vertical_profile_from_npz(
    npz_path: str,
    x0: float,
    y0: float,
    zmin: float,
    zmax: float,
    nz: int = 201,
    in_space: Literal["log10", "linear"] = "log10",
    out_space: Literal["log10", "linear"] = "linear",
    power: float = 2.0,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Build a vertical resistivity profile at (x0, y0) from a FEMTIC NPZ file.

    Parameters
    ----------
    npz_path : str
        NPZ file with at least 'centroid' and either 'log10_resistivity'
        or 'resistivity'. Optional 'flag' with 1 = fixed.
    x0, y0 : float
        Horizontal coordinates of the borehole.
    zmin, zmax : float
        Depth range for the profile.
    nz : int, optional
        Number of depth samples.
    in_space : {'log10', 'linear'}, optional
        Interpretation of stored values. If 'linear', they are converted
        to log10 internally.
    out_space : {'log10', 'linear'}, optional
        Desired output space for the profile.
    power : float, optional
        IDW power exponent.

    Returns
    -------
    z_samples : ndarray, shape (nz,)
        Depth samples.
    profile : ndarray, shape (nz,)
        Profile values in out_space (linear or log10).
    """
    data = np.load(npz_path)
    if "centroid" not in data:
        raise KeyError("NPZ must contain 'centroid'.")

    centroids = data["centroid"]

    if "log10_resistivity" in data and in_space == "log10":
        vals_log10 = data["log10_resistivity"]
    elif "resistivity" in data and in_space == "linear":
        vals_log10 = np.log10(np.clip(data["resistivity"], 1e-30, np.inf))
    else:
        raise KeyError("Need 'log10_resistivity' (in_space='log10') or 'resistivity' (in_space='linear').")

    if "flag" in data:
        mask = data["flag"] != 1
        centroids = centroids[mask]
        vals_log10 = vals_log10[mask]

    z_samples = np.linspace(zmin, zmax, nz)
    prof_log10 = _idw_profile(x0, y0, z_samples, centroids, vals_log10, power=power)

    if out_space == "log10":
        profile = prof_log10
    else:
        profile = 10.0 ** prof_log10

    return z_samples, profile


def main() -> None:
    """
    CLI to compute and plot vertical profiles from FEMTIC NPZ element arrays.

    Example
    -------
    python -m femtic_profiles \\
        --npz elements_arrays.npz \\
        --x 1000 --y 500 \\
        --zmin -2000 --zmax 0 --nz 201 \\
        --in-space log10 --out-space linear \\
        --logx --z-positive-down \\
        --out-png borehole_profile.png
    """
    import argparse

    ap = argparse.ArgumentParser(description="Vertical profiles from FEMTIC NPZ arrays (IDW).")
    ap.add_argument("--npz", required=True, help="NPZ with 'centroid' and log10 or linear values.")
    ap.add_argument("--xy", action="append", nargs=2, type=float, metavar=("X", "Y"),
                    help="Add borehole at (X,Y); may be repeated.")
    ap.add_argument("--x", type=float, help="X of single borehole if --xy not used.")
    ap.add_argument("--y", type=float, help="Y of single borehole if --xy not used.")
    ap.add_argument("--zmin", type=float, required=True)
    ap.add_argument("--zmax", type=float, required=True)
    ap.add_argument("--nz", type=int, default=201)
    ap.add_argument("--in-space", choices=["log10", "linear"], default="log10")
    ap.add_argument("--out-space", choices=["log10", "linear"], default="linear")
    ap.add_argument("--power", type=float, default=2.0)
    ap.add_argument("--logx", action="store_true")
    ap.add_argument("--z-positive-down", action="store_true")
    ap.add_argument("--out-png", default=None)
    args = ap.parse_args()

    coords: List[tuple] = []
    if args.xy:
        coords = [(float(x), float(y)) for x, y in args.xy]
    elif args.x is not None and args.y is not None:
        coords = [(args.x, args.y)]
    else:
        raise ValueError("Provide borehole coordinates via repeated --xy X Y or single --x and --y.")

    profiles_plot = []
    labels = []

    for (x0, y0) in coords:
        z_samples, prof = vertical_profile_from_npz(
            args.npz,
            x0,
            y0,
            args.zmin,
            args.zmax,
            nz=args.nz,
            in_space=args.in_space,
            out_space=args.out_space,
            power=args.power,
        )
        if args.logx and args.out_space == "log10":
            prof_plot = 10.0 ** prof
        else:
            prof_plot = prof
        profiles_plot.append(prof_plot)
        labels.append(f"({x0:g},{y0:g})")

    fig, ax = plot_vertical_profiles(
        z_samples,
        profiles_plot,
        labels=labels,
        logx=args.logx,
        z_positive_down=args.z_positive_down,
    )

    if args.out_png:
        fig.savefig(args.out_png, dpi=200, bbox_inches="tight")
        print("Saved:", args.out_png)
    else:
        try:
            plt.show()
        except Exception:
            pass


if __name__ == "__main__":
    main()
